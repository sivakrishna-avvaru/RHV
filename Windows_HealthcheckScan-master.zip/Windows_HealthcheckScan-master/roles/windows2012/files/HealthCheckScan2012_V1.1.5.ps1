﻿<##########################################################################################
#   Name     : HealthCheckScan2012_V1.1.5                                                 #
#   Version  : 1.1.5                                                                      #
#   Version History:                                                                      #
#   1.0.0    : Initial Version. ( 09 Apr 20120 )                                          #
#   1.0.1    : Fixes for 1.8.26.1,1.8.26.2,1.5.18.1,1.5.18.2                              # 
#              Added a function call for HIPPA    ( 21-Apr-2020)                          #
#   1.0.2    : Added Missing Parameters with related to old verstion tech spec            #
#              1.1.9.3,1.1.9.4,1.1.1.9.5,1.5.1,1.5.7.5,1.5.7.6,1.8.32 and 1.8.33          #
#              Display AccountName in the Scan Results                                    # 
#              Display OS Version in the scan Results                                     #
#              Display Scan version                                                       #
#              Added a new column with TimeStamp  ( 30-Apr-2020 )                         #
#   1.0.3    : Added variables #accountID,#customsedDate,#customisedBy                    #
#              Added #1.9.2,1.2.58,1.2.59,1.8.22-1.8.25 (19 MAY 2020)                     #
#   1.0.4    : Added FQDN and IP Address in the scan results.                             #
#              Added #1.2.62 ( 04-Jun-2020 )                                              #
#   1.0.5    : Added TechSpec Version in the scan results                                 #
#              Added #1.2.61                                                              # 
#              Fixed #1.5.9,1.8.5,1.8.16,1.8.17,1.8.21  ( 22-Jul-2020 )                   #
#   1.1.5    : Improved 1.2.58,1.2.59                                                     #
#              Updated commands used Get-ItemProperty                                     #
#                                                                                         #
#   Date     : 11-Nov-2020			       		                                          #
#	Platform : Windows						      		                                  #
#	Script   : Power-Shell script which can be run on 2012)                               #				               
#	Developer: Lavanya Botcha ( lbotcha1@in.ibm.com )                                     #
#   Customised By: "SCS Focal"                                                            #
###########################################################################################>


#*******************Tech Spec should be converted in CSV format ***************************

param( $TechSpecCSD, $accountName, $accountID, $customisationDate, $scanVersion )

$pathCsv = $TechSpecCSD

if($pathCsv -ne $null) {
  if(Test-Path $pathCsv) { $extn = [IO.Path]::GetExtension($pathCsv)
    if ($extn -ne ".csv" )  { $pathCsv = Read-Host 'Please enter Windows 2012 TechSpec file in CSV Format:' }
  } else { $pathCsv = Read-Host 'Please enter Windows 2012 TechSpec file name(CSV Format):' }
} else { $pathCsv = 'Microsoft Windows Server 2012 v4.1.csv'}

#************  $scanType = "HIPPA" when the system is HIPPA complaint.- UPDATE THE VARIABLE *******************

$scanType = "BaseLine" 
#scanType = "HIPPA"

#************* PROVIDE ACCOUNT NAME *********************

if($accountName -eq $null) { $accountName = "ACCOUNT-NAME" }
if($accountID -eq $null) { $accountId = "AccountID" }
if($customisedDate -eq $null) { $customisedDate = 'customisedDate(mmDDyyyy)' }

#******** PROVIDE DOMAIN IF SECTION#1.2.62 EXISTS *****

$domainName = "mcms.com"

#**************** PROVIDE VERSION NUMBER ****************

if($scanVersion -eq $null) { $scanVersion = "1.1.5" }
$techSpecVersion = "v4.1"

#$ErrorActionPreference= 'SilentlyContinue'
$scriptpath = split-path $myinvocation.mycommand.definition
$compName = $env:computername
$FQDN=(Get-WmiObject win32_computersystem).DNSHostName+"."+(Get-WmiObject win32_computersystem).Domain
$IP = Get-NetIPAddress -AddressState Preferred -AddressFamily IPv4 | Select-object IPAddress,InterfaceAlias | where-object { $_.InterfaceAlias -match "Ethernet" }
$ipAddress = $($IP.IPAddress)
$scanDate = Get-Date -Format "MM/dd/yyyy"
$timestamp = Get-Date -Format yyyy-MM-dd-hh.mm.ss.000000
$scanDate = $scanDate+"|"+$timestamp
$fileFormat = $compName+"_"+(Get-date -f MMddyyyy)+".csv"
$fileName = "$scriptpath\$fileFormat"
$wmi_os = Get-WmiObject -class Win32_OperatingSystem -ComputerName $compName | select CSName,Caption,Version,OSArchitecture,LastBootUptime
$osName = $($wmi_os.Caption)

#Remove the Scan results file if exists, before running scan.
if( Test-Path -Path $fileName ) { Remove-Item $fileName }


write-output "ACCOUNT: $accountName - $accountId" > $fileName
write-output "TechSpec Version: $techspecVersion" >> $fileName
Write-Output "Customisation Date: $customisedDate" >> $fileName
#Write-Output "OS-VERSION: $($wmi_os.Caption)" >> $fileName
Write-Output "SCAN-VERSION: $scanVersion" >> $fileName
Write-Output "********************************************************************************************" >> $fileName
Write-Output "HOST-NAME|FQDN|IP-ADDRESS|OS-NAME|SECTION-ID|SECTION-HEADING|SYSTEM-VALUE/PARAMETER|AGREED-VALUE|CURRENT-VALUE|TEST-RESULT|SCAN-DATE|TIMESTAMP" >> $fileName

<#
  Function: GetEventLogData
  Description: It Retreieves the list of EventLogs in a system.
  Returns: OverFlowAction , Retention and Size of the specified Log
#>

function GetEventLogData {
   
  Param ([String]$category)
  $importEventLog = @()
  $eventLogdata = Get-EventLog -List

  foreach($evItem in $eventLogdata){

    $hash = @{
        overFlowAction = $evitem.OverflowAction
        Log = $evitem.Log
        Retain = $evitem.MinimumRetentionDays
        MaxSize = $evitem.MaximumKilobytes
    }
  $eventobjTemp = new-object psobject -property $hash
  $importEventLog += $eventobjTemp
  }
  ForEach ( $s in $importEventLog) {
  if($s.Log -match $category) {
     $size = $s.MaxSize
     $Log = $s.Log
     $Retain = $s.Retain
     $overflowAction = $s.overFlowAction

  return $overflowAction,$Retain,$size

} }  }

<# 
  Function: HIPPA_ParamCheck
  Description: This function gets executed only based on $scanType valriable is defined to "HIPPA". 
               It executes the script called - HealthCheckScan_HIPPA_V1.0.0.ps1 which works on HIPPA Params
#>
function HIPPA_ParamCheck {
   Param ([Object[]]$importTable, [string]$filename)
   #& ((Split-Path $MyInvocation.InvocationName) + "\HealthCheckScan_HIPPA_V1.0.0.ps1") -importTable $importTable -fileName $filename
   .\\HealthCheckScan2012_HIPPA_V1.0.0.ps1 -importTable $importTable -fileName $filename
}

<#
  Function: GetAntiVirusCheck
  Description: It checks whether the Antivirus is installed or not.( Default: Symantec and Mcaffee services have been included to check)

#>
function GetAntiVirusCheck {
    $antiVirusSoftware = get-wmiobject -class "Win32_Product" -namespace "root\cimv2"-computername "." -filter "Name like '%antivirus%'"
    if( $antiVirusSoftware.count -gt 0) {
       $software = $antiVirusSoftware.Name
       if($software -match "symantec") {
          $serviceName = "SEP14.1"
          $results = GetServiceCheck -serviceName $serviceName
          $testResult = $results[0]
          $currentValue = $results[1]
        }
       elseif($software -match "mcafee") {
        $serviceName = @("McShield","McTaskManager","McFramework")
        ForEach($srvcName in $serviceName) {
        $results = GetServiceCheck -serviceName $srvcName
        $testResult = $results[0]
        $currentValue = $results[1]
       }
       } else { $currentValue = $software+ " installed.Please check the status ";$testResult = "No" }
    }else { $currentValue = "NO AntiVirus Installed";$testResult = "No" }
   return  $testResult,$currentValue
}

<# 
  Function: GetServiceCheck
  Descrition: It Checks whether the service is available and if it is available,it checks whether it is running or not.
  Returns: The current state of the service  and the testResult.
#>
function GetServiceCheck {
  
  Param ([String]$serviceName)
  If (($serviceName -eq "CHARGEN") -or ($serviceName -eq "ECHO") -or ($serviceName -eq "DAYTIME") -or ($serviceName -eq "DISCARD")) {
     $service = "simptcp"
  }
  elseif($serviceName -match "FTP") { $service = "FTPSVC" }
  elseif($serviceName -match "Telnet") { $service = "TlntSvr" } 
  elseif($serviceName -match "NNTP") { $service = "NNTP" } 
  elseif($serviceName -match "REXD") { $service = "rexd" } else  { $service = $serviceName }
    
  if (Get-Service $service -ErrorAction SilentlyContinue) {

    if ((Get-Service $service).Status -eq 'Running') {
          $testResult = "No"
          $cVal = "RUNNING: "+$serviceName 
    } else {
        $testResult = "Yes"
        $cVal = "NOT RUNNING: " + $serviceName   }
  }else { 
    $testResult = "Yes"
    $cVal = "NOT FOUND: "+$serviceName }

    return $testResult,$cVal
  }

<#
  Function: TestResult-OSR
  Description: It retrieves ACL rules for a specific $osr_path. 
  Returns: The result of Get-ACL command and the testResult.
#>
function TestResult-OSR {

     Param ([String]$osr_path)

     if (Test-Path -Path $osr_path) { 
               #$currentValue = Get-Acl $osr_path -Audit |  select -expandproperty audit | where-object { $_.FileSystemRights -match "ReadAndExecute" -and $_.AuditFlags -match "Failure" } | findstr "Everyone False" 
               $currentValue = (get-acl $osr_path).access | where-object { $_.FileSystemRights -match "ReadAndExecute" } | findstr "Users"
               if($lastExitCode -eq 0) { $testResult = "Yes" } else { $currentvalue = "PERMISSIONS NOT SET"; $testResult = "No" } 
     }
     else { 
               $currentValue = "NOT FOUND:" + $osr_path
               $testResult= "Yes" }

return $currentValue,$testResult
}

<#
  Function: AuditLog-OSR
  Description: It retrieves ACL rules for a specific $osr_path. 
  Returns: The result of Get-ACL command and the testResult.
#>
function AuditLog-OSR {

     Param ([String]$path)

     if (Test-Path -Path $path) { 
               #$currentValue = Get-Acl $path -Audit |  select -expandproperty audit | where-object { $_.FileSystemRights -match "Modify" -and $_.FileSystemRights -match "FullControl" -and $_.AuditFlags -match "Failure" } | findstr "Everyone False" 
                $currentValue = Get-Acl $path -Audit |  select -expandproperty audit | where-object { ($_.FileSystemRights -match "DeleteSubdirectoriesAndFiles, Modify, ChangePermissions, TakeOwnership" -or "FullControl") -and $_.AuditFlags -match "Failure" } | findstr /I "Everyone False" 
               if($lastExitCode -eq 0) { $testResult = "Yes" } else { $currentvalue = $path+" - Audit Rule NOT SET"; $testResult = "No" } 
     }
     else { 
               $currentValue = "NOT FOUND:" + $path
               $testResult= "Yes" }

return $currentValue,$testResult
}

<#
  Function: Get-ScheduledTasks
  Description: It retrieves the list of scheduled tasks for specified test path. ( Default : TestPath - \ ) 
#>
function Get-ScheduledTasks {
   
   Param([String]$scheduledTaskPath)
    
   $ErrorActionPreference= 'SilentlyContinue'
   if(Test-Path -Path $scheduledTaskPath) {
   $taskList =  Get-ScheduledTask -TaskPath $scheduledTaskPath | Where-Object {($_.State -like '*Ready*') -or ($_.State -like '*Disabled*') -or ($_.State -like '*Running*')}
   if($?){
   } else {
            $taskList = "No TaskList Found for the Specified path. Please check manually" }
   } else { $taskList = "NOT FOUND: $scheduledTaskPath on this server. Please check manually" }
   #$ErrorActionPreference= 'Continue'
   return $taskList
}

<# 
   Function: GetSynchronisedSystemClockdetails
   Note: nltest gets executed only the privileges are elevated permissions to query the domain controller. 
   you are not supposed to use nltest with workgroups ( servers which are not added to domains )
#>
function GetSynchronisedSystemClockdetails { 
  
  Param([String]$domain)
  
  $domainlist = nltest /dclist:$domain
  $timesync = w32tm /query /source
  if($timesync -match "not been started") {$currentValue = "Windows Time Service is not Running"; $testResult = "No"}
   elseif ($timesync -match "Free-running System Clock") { $currentValue = "not mapped to any domain"; $testResult = "No"}
   elseif ($domainlist -match $timesync) { $currentValue = "in sync with "+$timesync ; $testResult = "Yes" }
   else { $currentValue = "please contact local administrator to check manually"; $testResult = "No" }
  return $currentValue, $testResult
}

<#
 Function: checkReadPermissions
   Description: Retrieves all the local users accounts that have ReadKey permission on the specific registry 
   testResult: No if the general users should have RegistryRights with ReadKey only.
#>
function checkReadPermissions {

  Param([String]$compName, $path)
   
   if (Test-Path -Path $path) {   
   $users = Get-WmiObject -ComputerName $compName -Class Win32_UserAccount -Filter "LocalAccount='True'" | Select Name
   $currentValue = (Get-ACL $path).Access | where-Object {($_.IdentityReference -in $users) -and ($_.RegistryRights -match "ReadKey")} | select IdentityReference
   
   if($currentValue -ne $null ) { $testResult = "Yes" } 
      else { $currentValue = (Get-ACL $path).Access | where-Object {($_.IdentityReference -in $users)} | select IdentityReference; 
          if($currentValue) { $testResult = "No" } else { $currentValue = "No General Users Found";$testResult = "Yes" } }
   
   } else {
          $currentValue = "NOT FOUND:" + $path
          $testResult= "Yes" }

   return $currentValue, $testResult

}
<# Function: permitGeneralUsers
   Description: Retrieves all the local users accounts and check whether they have the autherization on the specific path
   testResult: No if the users are autherized to access the path.
#>
function permitGeneralUsers {

  Param([String]$compName, $path)
   
   $curValue = @()

   if (Test-Path -Path $path) {   
       $users = Get-WmiObject -ComputerName $compName -Class Win32_UserAccount -Filter "LocalAccount='True'" | Select Name
       #Select PSComputername, Name, Status, Disabled, AccountType, Lockout, PasswordRequired, PasswordChangeable, SID 
   
      
         $curVal = (Get-ACL -Path $path).Access.IdentityReference | Where-Object {($_.Value -in $users.Name) -and ($_.Value -notlike '*NT*') -and ($_.Value -notlike '*BUILTIN*')}
      
       if($curVal) { $currentValue = $curVal.Value;$testResult = "No" } else { $currentValue = "No General Users Found";$testResult = "Yes" }
       
   }
   else {
          $currentValue = "NOT FOUND:" + $path
          $testResult= "Yes" }

   return $currentValue, $testResult

}

<#*************************** Read the data from the TechSpec CSV ****************************#>
#$pathCsv = "Microsoft Windows Server 2012 v4.1.csv"
$importTable = @()
$data = import-csv -path $pathCsv

foreach($item in $data){

    $hash = @{
        Section = $item.Section
        Heading  = $item.SectionHeading
        AgreedValue = $item.RecommendedValue.Replace("`n", ", ")
        Parameter = $item.Parameter.Replace("`n", ", ")        
    }
    $objTemp = new-object psobject -property $hash
    $importTable += $objTemp
}
secedit.exe /export /cfg C:\secconfig.cfg
<# OSRs #>
        $systemRoot = "C:\Windows"
        $winDir = "C:\Windows"
        $systemDrive = "C:\"
        $security_path = "$systemRoot\security"
        $system_path = "$systemRoot\system"
        $system32_path = "$systemRoot\system32"
        $config_path = "$systemRoot\system32\config"
        $drivers_path = "$systemRoot\system32\drivers"
        $spool_path = "$systemRoot\system32\spool"
        $groupPolicy_path = "$systemRoot\system32\GroupPolicy"
        $backup_path = "$winDir\WinSxS\Backup"
        $bcd_path = "$systemDrive\boot\BCD"
        $winload_path = "$systemRoot\system32\winload.exe"
        $bootMgr_path = "$systemDrive\bootmgr"
        $sysWow64_path = "$systemRoot\syswow64"
        $sysWow64Drivers_path = "$systemRoot\syswow64\drivers"
        $securityEvtx_path = "$systemRoot\System32\Winevt\Logs\Security.evtx"
        $dnsServerEvtx_path = "$systemRoot\System32\Winevt\Logs\DNS Server.evtx"
        $eventLogSecutiry_path = "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Security"
        $hkey_classes_root = "HKLM:\Software\Classes"
        $securityEventLog_path = "HKLM\SYSTEM\CurrentControlSet\Services\EventLog\Security"

Foreach ($data in $importTable) {
# write-output $data
 Switch -Wildcard ( $data.Heading ) {
  "*Password Requirements*" { 
        Switch -Wildcard ( $data.Section ) {
                       
             "*1.1.1" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "PasswordHistorySize" 
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue 
                        $curValue = 0+$currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                        $rValue = $recommended -replace '(\d+).*','$1'
                        if($curValue  -match "^\d+$") {
                        if($curValue -ge $rValue) { $testResult = "Yes" } else { $testResult = "No" } }
                        else { $testResult = "No" }
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

             "*1.1.2" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "MinimumPasswordAge"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                        $rValue = $recommended -replace '(\d+).*','$1'
                        if($curValue -eq $rValue) { $testResult = "Yes" } else { $testResult = "No" }
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

             "*1.1.3" { $currentValue = net ACCOUNTS | findstr "password" | findstr "age" | findstr "Maximum"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        $curValue = 0+$currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ','')
                        $rValue = $recommended -replace '(\d+).*','$1'
                        if($curValue -le $rValue) { $testResult = "Yes" } else { $testResult = "No" }
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

             "*1.1.4" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "MinimumPasswordLength"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        $curValue = 0+($currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ',''))
                        $rValue = $recommended -replace '(\d+).*','$1'
                        if($curValue -ge $rValue) { $testResult = "Yes" } else { $testResult = "No" }
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

           "*1.1.4.1" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "PasswordComplexity"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                        if($curValue -eq 1) { $testResult = "Yes" } else { $testResult = "No" } 
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
                           
             "*1.1.5" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "ClearTextPassword"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                          if($curValue -eq 0) { $testResult = "Yes" } else { $testResult = "No" } 
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
 
             "*1.1.6" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "LockoutBadCount"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        if($currentValue -ne $null) {
                        $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                        $rValue = $recommended -replace '(\d+).*','$1'
                        if($curValue -eq $rValue) { $testResult = "Yes" } else { $testResult = "No" } }
                        else { $testResult = "No";$curValue = "NOT SET" }
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
             
             "*1.1.7" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "LockoutDuration" 
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        if($currentValue -ne $null) {
                        $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                        $rValue = $recommended -replace '(\d+).*','$1'
                        if($curValue -eq $rValue) { $testResult = "Yes" } else { $testResult = "No" } } else { $testResult = "No"; $curValue = "NOT SET" } 
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

             "*1.1.8" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "ResetLockoutCount"
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                        if($currentValue -ne $null) {
                        $curValue = 0+($currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ',''))
                        $rValue = $recommended -replace '\D+(\d+).*','$1'
                        if($curValue -eq $rValue) { $testResult = "Yes" } else { $testResult = "No" }  } else { $testResult = "No";$curValue="NOT SET" }  
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

             "*1.1.9.1" { $currentValue = Get-WmiObject -Class Win32_UserAccount -computername $compName | Where {$_.PasswordExpires -like '*False*' -and $_.Name -NotLike '*Guest*'} | Select Name
                          $section = $data.Section
                          $heading = $data.Heading
                          $parameter = "Passwords used in non-interactive logins"
                          $recommended = $data.AgreedValue
                          $testResult = "No"
                          if($currentValue -ne $null -or $currentValue -ne "") { $currentValue = $currentValue.Name } else { $currentValue = "Not Set"; $testResult = "No" }
                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
                          }

             "*1.1.9.2" { $currentValue = net user Replicate | findstr "expires" | findstr "Password" 
                          $section = $data.Section
                          $heading = $data.Heading
                          $parameter = $data.Parameter
                          $recommended = $data.AgreedValue
                          if($currentValue -ne $null -or $currentValue -ne "") { if ($currentValue -match "Never") { $testResult = "Yes" } else { $currentValue = "Please contact local Administrator to check Manually"; $testResult = "No" } }
                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.1.9.3" { $currentValue = net user guest | findstr "expires" | findstr "Password" 
                          $section = $data.Section
                          $heading = $data.Heading
                          $parameter = $data.Parameter
                          $recommended = $data.AgreedValue
                          if($currentValue -ne $null -or $currentValue -ne "") { if ($currentValue -match "Never") { $testResult = "Yes" } else { $currentValue = "Not Set"; $testResult = "No" } }
                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.1.9.4" { $currentValue = (Get-WmiObject -Class Win32_UserAccount).Name | findstr "IUSR IWAM"
                          $section = $data.Section
                          $heading = $data.Heading
                          $parameter = $data.Parameter
                          $recommended = $data.AgreedValue
                          if($currentValue.count -ge 1) {
                            ForEach($user in $currentValue) {   
                              $curValue = net user $user |findstr "expires" | findstr "Password"
                                if($curValue -match "Never") { $testResult = "Yes" } else { $testResult = "No"}
                            write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$user : $curValue|$testResult|$scanDate" >> $fileName  
                            }
                          }else {$curValue = "No IIS users found"; $testResult = "Yes" 
                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName } }

             "*1.1.9.5" { $currentvalue = Get-WmiObject -Class Win32_UserAccount -Filter "PasswordExpires='False' AND Disabled='True'" | Select Name
                          $section = $data.Section
                          $heading = $data.Heading
                          $parameter = $data.Parameter
                          $recommended = $data.AgreedValue
                          $currentvalue = "Please contact local administrator to check manually"
                          $testResult = "No"
                          if($currentValue -ne $null) { $currentValue = $currentValue.Name } else { $currentValue = "Not Set"; $testResult = "No" }
                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }
 }
}
  "*Logging*" { 
      Switch -regex ( $data.Section ) { 
                   "\D+\.1\.2\.1\z" { $currentvalue = AuditPol /get /category:* | findstr "Credential"
                                    $section = $data.Section
                                    $heading = $data.Heading
                                    $parameter = $data.Parameter
                                    $recommended = $data.AgreedValue
                                    if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                    $curValue = $currentValue.Substring(42)
                                    write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
                    
 
                  "\D+\.1\.2\.2\z" { $currentValue = AuditPol /get /category:* | findstr "Kerberos" | findstr /I "Ticket"
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
 
                 "\D+\.1\.2\.3\z" { $currentValue = AuditPol /get /category:* | findstr "Other" | select -Last 1
                                    $section = $data.Section
                                    $heading = $data.Heading
                                    $parameter = $data.Parameter
                                    $recommended = $data.AgreedValue   
                                    if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else {$testResult = "No" }
                                    $curValue = $currentValue.Substring(42)
                                    write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                  "\D+\.1\.2\.4\z" { $currentValue = AuditPol /get /category:* | findstr "Kerberos" | select -Last 1 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                  "\D+\.1\.2\.5\z" { $currentValue = AuditPol /get /category:*  | findstr "Logon" | select -First 2 | select -Last 1
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                  "\D+\.1\.2\.6\z" { $currentValue = AuditPol /get /category:*  | findstr "Logoff" | select -First 2 | select -Last 1
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.7\z" { $currentValue = AuditPol /get /category:*  | findstr "Account" | findstr "Lockout"
                                    $section = $data.Section
                                    $heading = $data.Heading
                                    $parameter = $data.Parameter
                                    $recommended = $data.AgreedValue   
                                    if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                    $curValue = $currentValue.Substring(42)
                                    write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.8\z" { $currentValue = AuditPol /get /category:*  | findstr "IPsec" | findstr "Main" 
                                    $section = $data.Section
                                    $heading = $data.Heading
                                    $parameter = $data.Parameter
                                    $recommended = $data.AgreedValue   
                                    if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                    $curValue = $currentValue.Substring(42)
                                    write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.9\z" { $currentValue = AuditPol /get /category:*  | findstr "IPsec" | findstr "Quick" 
                                    $section = $data.Section
                                    $heading = $data.Heading
                                    $parameter = $data.Parameter
                                    $recommended = $data.AgreedValue   
                                    if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                    $curValue = $currentValue.Substring(42)
                                    write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
                         
                 "\D+\.1\.2\.10\z" { $currentValue = AuditPol /get /category:*  | findstr "IPsec" | findstr "Extended" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.11\z" { $currentValue = AuditPol /get /category:*  | findstr "Special" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.12\z" { $currentValue = AuditPol /get /category:*  | findstr "Other" | findstr "Logon/Logoff" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.13\z" { $currentValue = AuditPol /get /category:*  | findstr "Network" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.14\z" { $curentValue = AuditPol /get /category:*  | findstr "Device Claims" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.15\z" { $currentValue = AuditPol /get /category:*  | findstr "User" | findstr "Account" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

 
                 "\D+\.1\.2\.16\z" { $currentValue = AuditPol /get /category:*  | findstr "Computer" | findstr "Account"  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

             
                 "\D+\.1\.2\.17\z" { $currentValue = AuditPol /get /category:*  | findstr "Security" | findstr "Group" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

 
                 "\D+\.1\.2\.18\z" { $currentValue = AuditPol /get /category:*  | findstr "Distribution" | findstr "Group"  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

  
                 "\D+\.1\.2\.19\z" { $currentValue = AuditPol /get /category:*  | findstr "Application" | findstr "Group"  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.20\z" { $currentValue = AuditPol /get /category:*  | findstr "Account" | findstr "Other"  |findstr "Management"
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                          
                 "\D+\.1\.2\.21\z" { $currentValue = AuditPol /get /category:*  | findstr "Directory" | findstr "Access"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.22\z" { $currentValue = AuditPol /get /category:*  | findstr "Directory" | findstr "Changes"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
           
                                       
                 "\D+\.1\.2\.23\z" { $currentValue = AuditPol /get /category:*  | findstr "Directory" | findstr "Replication" | select -First 1
                                     if( $currentValue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.24\z" { $currentValue = AuditPol /get /category:*  | findstr "Directory" | findstr "Replication" | select -Last 1 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

 
                 "\D+\.1\.2\.25\z" { $currentValue = AuditPol /get /category:*  | findstr "File" | findstr "System"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }  
                                     $curValue = $currentValue.Substring(42)  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.26\z" { $currentValue = AuditPol /get /category:*  | findstr "Registry" 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }  
                                     $curValue = $currentValue.Substring(42)  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.27\z" { $currentValue = AuditPol /get /category:*  | findstr "Kernel" 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.28\z" { $currentValue = AuditPol /get /category:*  | findstr "SAM" 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }  
                                     $curValue = $currentValue.Substring(42)  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                                            
                 "\D+\.1\.2\.29\z" { $currentValue = AuditPol /get /category:*  | findstr "Certification" 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.30\z" { $currentValue = AuditPol /get /category:* | findstr "Application" | findstr "Generated"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.31\z" { $currentValue = AuditPol /get /category:*  | findstr "Handle"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.32\z" { $currentValue = AuditPol /get /category:*  | findstr "File" | findstr "Share" | select -First 1
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42)    
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.33\z" { $currentValue = AuditPol /get /category:*  | findstr "Filtering" | findstr "Drop"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

 
                 "\D+\.1\.2\.34\z" { $currentValue = AuditPol /get /category:*  | findstr "Filtering" | findstr "Connection" 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }  
                                     $curValue = $currentValue.Substring(42)  
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }


                 "\D+\.1\.2\.35\z" { $currentValue = AuditPol /get /category:*  | findstr "Other" | findstr "Object"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

 
                 "\D+\.1\.2\.36\z" { $currentValue = AuditPol /get /category:*  | findstr "Detailed" | findstr "Share"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)   
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue   
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                                     
                 "\D+\.1\.2\.37\z" { $currentvalue = AuditPol /get /category:*  | findstr "Removable" | findstr "Storage"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.38\z" { $currentvalue = AuditPol /get /category:*  | findstr "Central" | findstr "Staging"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42) 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.39\z" { $currentValue = AuditPol /get /category:*  | findstr "Audit" | findstr "Policy" | select -First 1
                                      if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.40\z" { $currentvalue = AuditPol /get /category:*  | findstr "Authentication" | findstr "Change"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }           
                         
                 "\D+\.1\.2\.41\z" { $currentValue = AuditPol /get /category:*  | findstr "Authorization"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         
 
                 "\D+\.1\.2\.42\z" { $currentValue = AuditPol /get /category:*  | findstr "MPSSVC"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }  
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         
                                    
                 "\D+\.1\.2\.43\z" { $currentValue = AuditPol /get /category:*  | findstr "Filtering" | findstr "Policy"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.44\z" { $currentValue = AuditPol /get /category:*  | findstr "Other" | findstr "Policy"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
                       

                 "\D+\.1\.2\.45\z" { $currentValue = AuditPol /get /category:*  | findstr "Sensitive" | select -Last 1
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.46\z" { $currentValue = AuditPol /get /category:*  | findstr "Sensitive" | select -First 1
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.47\z" { $currentValue = AuditPol /get /category:*  | findstr "Events" | findstr "Privilege"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" }  
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.48\z" { $currentValue = AuditPol /get /category:*  | findstr "Process" | findstr "Creation"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         
                 "\D+\.1\.2\.49\z" { $currentValue = AuditPol /get /category:*  | findstr "Process" | findstr "Termination"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         
                 "\D+\.1\.2\.50\z" { $currentValue = AuditPol /get /category:*  | findstr "DPAPI"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
                        

                 "\D+\.1\.2\.51\z" { $currentValue = AuditPol /get /category:*  | findstr "RPC"
                                     if( $currentValue -Match "Success and Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
                       

                 "\D+\.1\.2\.52\z" { $currentValue = AuditPol /get /category:*  | findstr "Security" | findstr "State"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.53\z" { $currentValue = AuditPol /get /category:*  | findstr "Security" | findstr "Extension"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         
            
                 "\D+\.1\.2\.54\z" { $currentValue = AuditPol /get /category:*  | findstr "System" | findstr "Integrity"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.55\z" { $currentValue = AuditPol /get /category:*  | findstr "IPsec" | findstr "Driver"
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" }
                                     $curValue = $currentValue.Substring(42) 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         
            
                 "\D+\.1\.2\.56\z" { $currentValue = AuditPol /get /category:*  | findstr "Other" | findstr "System" 
                                     if( $currentvalue -notmatch "Success" -and $currentValue -Match "Failure" )  { $testResult = "Yes" } else { $testResult = "No" } 
                                     $curValue = $currentValue.Substring(42)
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName }
         

                 "\D+\.1\.2\.57\z" { $currentValue = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Control\Lsa | findstr /I "SCENoApplyLegacyAuditPolicy"
                                     if($currentValue -eq $null) { $currentValue = "NOT SET: SCENoApplyLegacyAuditPolicy"; $testResult = "No" } else { $testResult = "Yes" } 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue.Replace("`n",",")
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }
       
               <#  "\D+\.1\.2\.58\z" { $currentValue = "No Action Required"
                                     $testResult = "Yes" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue.Replace("`n",",")
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

                 "\D+\.1\.2\.59\z" { $currentValue = "No Action Required"
                                     $testResult = "Yes" 
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue.Replace("`n",",")
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

#>

                  "\D+\.1\.2\.58\z" { $osr_folder_path = $systemRoot,$winDir,$systemDrive,$security_path,$system_path,$system32_path,$config_path,$drivers_path,$spool_path,$groupPolicy_path,$backup_path,$bootMgr_path,$sysWow64_path,$sysWow64Drivers_path
                                      foreach ( $folderPath in $osr_folder_path )
                                        {
                                          $osr_results = AuditLog-OSR -Path $folderPath 
                                          $section = $data.Section
                                          $heading = $data.Heading
                                          $parameter = $data.Parameter
                                          $recommended = $data.AgreedValue.Replace("`n",",")
                                          $currentValue  = $osr_results[0]
                                          $testResult = $osr_results[1]
                                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }}

                  "\D+\.1\.2\.59\z" { $osr_file_path = $bcd_path,$winload_path,$securityEvtx_path,$dnsServerEvtx_path
                                      foreach ( $filePath in $osr_file_path )
                                        {
                                          $osr_results = AuditLog-OSR -Path $filePath 
                                          $section = $data.Section
                                          $heading = $data.Heading
                                          $parameter = $data.Parameter
                                          $recommended = $data.AgreedValue.Replace("`n",",")
                                          $currentValue  = $osr_results[0]
                                          $testResult = $osr_results[1]
                                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }}
           
                 "\D+\.1\.2\.61\z" { $eventLogInfo = GetEventLogData -category "Security"
                                      $retention = $eventLogInfo[1]
                          
                                     if( $retention -ne $null) {
                                      if( $retention -eq 90 ) { $testResult = "Yes" } else { $testResult = "No" }
                                     } else { $retention = "NOT SET:EventLog-Security-Retention"; $testResult = "No" }
                          
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue.Replace("`n",",")
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$retention|$testResult|$scanDate" >> $fileName  }
                
                 "\D+\.1\.2\.62\z" { $systemClockInfo = GetSynchronisedSystemClockdetails -domain $domainName
                                     $currentValue = $systemClockInfo[0]
                                     $testresult = $systemClockInfo[1]
                                     $section = $data.Section
                                     $heading = $data.Heading
                                     $parameter = $data.Parameter
                                     $recommended = $data.AgreedValue.Replace("`n",",")
                                     write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName  }

                    
            # default { write-output $data.Section } 
     }
   }
   "*AntiVirus*" { 
        Switch -Wildcard ( $data.Section ) {
          "*1.3.1" {
              $section = $data.Section
              $heading = $data.Heading
              $parameter = $data.parameter
              $recommended = $data.AgreedValue.Replace("`n",",")
              $serviceName = @("SepMasterService","McShield","McTaskManager","McFramework")
              ForEach($srvcName in $serviceName) {
                 $results = GetServiceCheck -serviceName $srvcName
                 $testResult = $results[0]
                 $currentValue = $results[1]
                 if($currentValue -match "Running") { $testResult = "Yes"; $currentValue="Enabled"; break } elseif($currentValue -match "NOT FOUND") {$currentValue = "Not Installed"; $testResult = "No"}
              }
              
             write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }
     
        }
   }
    
   "*Network Settings*" { 
        Switch -Wildcard ( $data.Section ) {
         "*1.5.1" { 
                   $section = $data.section
                   $heading = $data.Heading
                   $parameter = $data.parameter
                   $recommended = $data.AgreedValue.Replace("`n",",")
                   $results = GetServiceCheck -serviceName $parameter
                   $testResult = $results[0]
                   $currentValue = $results[1]
                   if($currentValue -match "NOT FOUND") { $currentValue =  "NO $parameter Found" } else { $testResult = "No"; $currentValue = "Please contact local Administrator to perform the operation."} 
                   write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
                  }

         "*1.5.2" { 
                   $section = $data.section
                   $heading = $data.Heading
                   $parameter = $data.parameter
                   $recommended = $data.AgreedValue.Replace("`n",",")
                   $testResult = "No"; 
                   $currentValue = "Please contact local Administrator to perform the operation." 
                   if($currentValue -match "NOT FOUND") { $currentValue =  "NO $parameter Found" } else { $testResult = "No"; $currentValue = "Please contact local Administrator to perform the operation."} 
                   write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
                  }

         "*1.5.3" { 
                   $section = $data.section
                   $heading = $data.Heading
                   $parameter = $data.parameter
                   $recommended = $data.AgreedValue.Replace("`n",",")
                   $results = GetServiceCheck -serviceName $parameter
                   $testResult = $results[0]
                   $currentValue = $results[1]
                   if($currentValue -match "NOT FOUND") { $currentValue =  "NO $parameter Found" } else { $testResult = "No"; $currentValue = "Please contact local Administrator to perform the operation."} 
                   write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
                  }


             {($data.section -match '1.5.4') -or ($data.section -match "1.5.5")} { 

               $section = $data.Section
               $heading = $data.Heading
               if($data.section -match "1.5.4") {$srvcName = "FTP"} else { $srvcName = "TFTP" }
               $recommended = $data.AgreedValue.Replace("`n",",")
               $results = GetServiceCheck -serviceName $srvcName
               $parameter = $data.parameter
               $testResult = $results[0]
               $currentValue = $results[1]
               if($currentValue -match "NOT FOUND") { $currentValue =  "NO "+$srvcName+" Service Found" } else { $testResult = "No"; $currentValue = "Please contact local Administrator to perform the operation."} 
               write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
             }
             
               {($data.section -match '1.5.6') -or ($data.section -match '1.5.7')} {
               $section = $data.Section
               $heading = $data.Heading
               $parameter = $data.Parameter
               $recommended = $data.AgreedValue.Replace("`n",",")
               $results = GetServiceCheck -serviceName  $parameter
               $testResult = $results[0]
               $currentValue = $results[1]
               write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
              }

              {($data.section -match '1.5.8')} {
                 $section = $data.Section
                 $heading = $data.Heading
                 $parameter = $data.Parameter
                 $recommended = $data.AgreedValue.Replace("`n",",")
                 $results = GetServiceCheck -serviceName $parameter
                 $testResult = $results[0]
                 $currentValue = $results[1]
                 if($currentValue -match "NOT FOUND") { $currentValue =  "NOT FOUND: "+$parameter } 
                 elseif($section -match "1.5.8.1") { 
                      if( Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\TrapConfiguration\public") 
                        { $testResult = "No"; $currentValue = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\TrapConfiguration\public | findstr 1 }
                      else { $currentValue = "No Community String: public"; $testResult = "Yes" } }
                  else {
                      if( Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\TrapConfiguration\private") 
                        { $testResult = "No"; $currentValue = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\TrapConfiguration\public | findstr 1 }
                      else { $currentValue = "No Community String: private"; $testResult = "Yes" }
                 } 
                 write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName
               }
             
             "*1.5.9" { $currentValue = Get-NetFirewallProfile | where {$_.Enabled -like '*True*'} | Select Name
                       if ($lastExitCode -eq 0) {
                            if($currentValue -ne $null) {
                               $testResult = "Yes"
                               $curValue = $currentValue.Name
                            } else { $testResult = "No"; $curValue = "Not Enabled" }
                         } else { $testResult = "No"; $curValue = "Please contact local Administrator to check manaully" }
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$curValue|$testResult|$scanDate" >> $fileName 
                      }
        #default { write-output "Network Settings" }
        }
   } 

   "*Identify and Authenticate Users*" { 
        Switch -Wildcard ($data.Section ) {
             "*1.7.0" {  
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue
                                
                        if (Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters") {
                           $cmd = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters | findstr /I "allowtgtsessionkey" | findstr "1" 
                           if ($lastExitCode -eq 0) {
                        
                                $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "MaxTicketAge"
                                if ($currentValue -ne $null) {
                                    $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                                    $rValue = $recommended -replace '\D+(\d+).*','$1'
                                    if($curValue -eq $rValue) { $testResult = "Yes" } else { $testResult = "No" }
                                } else { $testResult = "No"; $currentValue = "NOT SET" }
                            } else { $currentValue = "NOT ENABLED: Kerberos Authentication";$testResult = "Yes" }
                           } else { $currentValue = "NOT ENABLED: Kerberos Authentication";$testResult = "Yes" }
                          
                        Write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

        }
   }

   "*Protecting Resources - OSRs*" {
        Switch -Wildcard ($data.Section ) {
             "*1.8.1" { $osr_results = TestResult-OSR -osr_path $systemRoot 
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.2" { $osr_results = TestResult-OSR -osr_path $security_path 
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        Write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.3" { $osr_results = TestResult-OSR -osr_path $system_path 
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.4" { $osr_results = TestResult-OSR -osr_path $system32_path
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.5" { $osr_results = permitGeneralUsers -compName $compName -path $config_path
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.6" { $osr_results = TestResult-OSR -osr_path $drivers_path
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.7" { $osr_results = TestResult-OSR -osr_path $spool_path
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.8" { $osr_results = TestResult-OSR -osr_path $groupPolicy_path 
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.9" { $osr_results = TestResult-OSR -osr_path $backup_path
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        $currentValue  = $osr_results[0]
                        $testResult = $osr_results[1]
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }


             "*1.8.10" { $osr_results = TestResult-OSR -osr_path $bcd_path
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             
             "*1.8.11" { $osr_results = TestResult-OSR -osr_path $winload_path 
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.12" { $osr_results = TestResult-OSR -osr_path $bootMgr_path 
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.13" { $osr_results = TestResult-OSR -osr_path $systemDrive 
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.14" { $osr_results = TestResult-OSR -osr_path $sysWow64_path 
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.15" { $osr_results = TestResult-OSR -osr_path $sysWow64Drivers_path
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }

             "*1.8.16" { $osr_results = permitGeneralUsers -compName $compName -path $securityEvtx_path
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName } 

             "*1.8.17" { $osr_results = permitGeneralUsers -compName $compName -path $dnsServerEvtx_path
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName } 
             
             "*1.8.20" {  $osr_results = checkReadPermissions -compName $compName -path "HKLM:\Software\Classes"
                          $section = $data.Section
                          $heading = $data.Heading
                          $parameter = $data.Parameter
                          $recommended = $data.AgreedValue.Replace("`n",",")
                          $currentValue  = $osr_results[0]
                          $testResult = $osr_results[1]
                          write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }     
                    
            "*1.8.21" {  $osr_results = permitGeneralUsers -compName $compName -path "HKLM:\SYSTEM\CurrentControlSet\Services\Eventlog\Security"
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $currentValue  = $osr_results[0]
                         $testResult = $osr_results[1]
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    

           
           "*1.8.22" { if(Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Application") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Services\EventLog\Application | findstr /I "RestrictGuestAccess"
                         if( $lastExitCode -eq 0) {
                          if( $currentValue -match 1) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Application-RestrictGuestAccess"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Application-RestrictGuestAccess"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    
          
          
           "*1.8.23" { if(Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\Security") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Services\EventLog\Security | findstr /I "RestrictGuestAccess"
                         if( $lastExitCode -eq 0) {
                          if( $currentValue -match 1) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Security-RestrictGuestAccess"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Security-RestrictGuestAccess"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    

           "*1.8.24" { if(Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\System") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SYSTEM\CurrentControlSet\Services\EventLog\System | findstr /I "RestrictGuestAccess"
                         if( $lastExitCode -eq 0) {
                          if( $currentValue -match 1) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-System-RestrictGuestAccess"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-System-RestrictGuestAccess"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    

           "*1.8.25" { if(Test-Path -Path "HKLM:\SYSTEM\CurrentControlSet\Services\EventLog\DNS Server") {
                         $currentValue = Get-ItemProperty "Registry::HKLM\SYSTEM\CurrentControlSet\Services\EventLog\DNS Server" | findstr /I "RestrictGuestAccess"
                         if( $lastExitCode -eq 0) {
                          if( $currentValue -match 1) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-DNS Server-RestrictGuestAccess"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-DNS Server-RestrictGuestAccess"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    
     
                      
           "*1.8.26.1" { #$currentValue = Get-ScheduledTasks -scheduledTaskPath "\"
                         $currentValue = "Please contact local Administrator to check manually"  
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $testResult = "No"
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    
         
           "*1.8.26.2" { #$currentValue = Get-ScheduledTasks -scheduledTaskPath "\"
                         $currentValue = "Please contact local Administrator to check manually" 
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         $testResult = "No"
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    
       
                                                    
           "*1.8.27" { $currentValue = Get-ItemProperty Registry::HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer  | findstr /I "NoDrivetypeAutoRun"
                       if( $lastExitCode -eq 0) {
                         if($currentValue -ne $null) { $driveTypeAutoRun = 0+($currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ',''))
                            if( $driveTypeAutoRun -eq 255) { $testResult = "Yes" } else { $testResult = "No" }
                         } } else { $currentValue = "NOT SET:NoDriveTypeAutoRun"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    

             "*1.8.28" { if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Security") {
                         
                         $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Security | findstr /I "AutoBackupLogFiles"
                         if( $lastExitCode -eq 0) {
                          if( $currentValue -match 1) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Security-AutoBackupLogFiles"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Security-AutoBackupLogFiles"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    

             "*1.8.29" { if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\System") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\System | findstr /I "AutoBackupLogFiles"
                         if( $lastExitCode -eq 0) {
                          if( $currentValue -match 0) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-System-AutoBackupLogFiles"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-System-AutoBackupLogFiles"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }    

             "*1.8.30" { if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Application") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Application | findstr /I "AutoBackupLogFiles"
                         if( $lastExitCode -eq 0) {
                           $autoBackupLog = $currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ','')
                          if( $autoBackupLog -eq 0) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Application-AutoBackupLogFiles"; $testResult = "No" } 
                         } else { $currentValue = "NOT SET:EventLog-Application-AutoBackupLogFiles"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }  
                         
             "*1.8.31" { if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Security") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Security | findstr /I "Retention"
                         if($lastExitCode -eq 0) {
                            if($currentValue -ne $null) { $eventLogBehaviour = $currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ','')
                                if( $eventLogBehaviour -eq 1 ) { $testResult = "Yes" } else { $testResult = "No" }
                            } } else { $currentValue = "NOT SET:EventLog-Security-Control EventLog Behaviour when it is full"; $testResult = "No" }
                            } else { $currentValue = "NOT SET:EventLog-Security-Control EventLog Behaviour when it is full"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }                  
             
             "*1.8.32" { if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\System") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\System | findstr /I "Retention"
                         if($lastExitCode -eq 0) {
                            if($currentValue -ne $null) { $eventLogBehaviour = $currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ','')
                                if( $eventLogBehaviour -eq 1 ) { $testResult = "Yes" } else { $testResult = "No" }
                            } } else { $currentValue = "NOT SET:EventLog-System-: Retention"; $testResult = "No" }
                            } else { $currentValue = "NOT SET:EventLog-System-: Retention"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }                  
             
              "*1.8.33" { if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Application") {
                         $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Application | findstr /I "Retention"
                         if($lastExitCode -eq 0) {
                            if($currentValue -ne $null) { $eventLogBehaviour = $currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ','')
                                if( $eventLogBehaviour -eq 1 ) { $testResult = "Yes" } else { $testResult = "No" }
                            } } else { $currentValue = "NOT SET:EventLog-Application: Retention"; $testResult = "No" }
                            } else { $currentValue = "NOT SET:EventLog-Application: Retention"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }                  
             
             "*1.8.34" { $eventLogInfo = GetEventLogData -category "Security"
                         $retentionMethod = $eventLogInfo[0]
                          
                         if( $retentionMethod -ne $null) {
                          if( $retentionMethod -match "OverwriteOlder") { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $retentionMethod = "NOT SET:EventLog-Security-RetentionMethod"; $testResult = "No" }
                        
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$retentionMethod|$testResult|$scanDate" >> $fileName }    
              
              "*1.8.35" { $eventLogInfo = GetEventLogData -category "Security"
                          $retention = $eventLogInfo[1]
                          
                         if( $retention -ne $null) {
                          if( $retention -eq 90 ) { $testResult = "Yes" } else { $testResult = "No" }
                         } else { $retention = "NOT SET:EventLog-Security-Retention"; $testResult = "No" }
                          
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$retention|$testResult|$scanDate" >> $fileName  }
              
              "*1.8.36" { 
                         if(Test-Path -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Security") {
                         $currentvalue = Get-ItemProperty Registry::HKLM\SOFTWARE\Policies\Microsoft\Windows\Eventlog\Security | findstr /I "MaxSize"
                         if( $lastExitCode -eq 0) {
                         if($currentValue -ne $null) { $maxSize = 0+($currentValue.SubString($currentValue.IndexOf(':')+1).replace(' ',''))
                            if( $maxSize -ge 20480 -and $maxSize -le 2147483647 ) { $testResult = "Yes" } else { $testResult = "No" }
                         } } else { $currentValue = "NOT SET:EventLog-Security-MaximumSize"; $testResult = "No" }
                         } else { $currentValue = "NOT SET:EventLog-Security-MaximumSize"; $testResult = "No" }
                         $section = $data.Section
                         $heading = $data.Heading
                         $parameter = $data.Parameter
                         $recommended = $data.AgreedValue.Replace("`n",",")
                         write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName }
                 
          }
   }

   "*Protecting Resources - User Resources*" {
        Switch -Wildcard ( $data.Section ) {
             "*1.9.1" {  }
             "*1.9.2" { $currentValue = Get-Content -Path C:\secconfig.cfg | findstr "EnableGuestAccount"
                        if($currentValue -ne $null) { $curValue = $currentValue.SubString($currentValue.IndexOf('=')+1).replace(' ','')
                           if($curValue -eq 0) { $testResult = "Yes" } else { $currentValue = "Please contact local Administrator to perform the operation"; $testResult = "No" }
                        }else { $testResult = "No"; $currentValue = "NOT SET" }
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName  } 
        }
   }

   "*Business Use Notice*" {
        Switch -Wildcard ( $data.Section ) {
             "*2.0.1" {$currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system | select-object -expandproperty "legalnoticecaption" 
                       if ($lastExitCode -eq 0) {
                        if ($currentValue -match "Business Use Notice")  { $testResult = "Yes" } else { $testResult = "No" }
                       }else { $currentValue = "legalNoticecaption doesnt exist"; $testResult = "No" }
                       $section = $data.Section
                       $heading = $data.Heading
                       $parameter = $data.Parameter
                       $recommended = $data.AgreedValue.Replace("`n",",")
                       write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName  }

             "*2.0.2" { $currentValue = Get-ItemProperty Registry::HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system | select-object -expandproperty "legalnoticetext"
                        if ($lastExitCode -eq 0) {
                        #$legalNoticeText = $currentValue.SubString($currentValue.IndexOf(':')+1)
                           if ($currentValue -eq $null -or $currentValue -eq " ")  { $testResult = "No" } 
                           elseif($currentValue -match "This system must be only used for conducting business work or for purposes authorized by the management.") { $testResult = "Yes" } else { $testResult = "No" }
                       }else { $currentValue = "NOT SET:legalNoticecaption"; $testResult = "No" }
                        $section = $data.Section
                        $heading = $data.Heading
                        $parameter = $data.Parameter
                        $recommended = $data.AgreedValue.Replace("`n",",")
                        write-output "$compName|$FQDN|$ipAddress|$osName|$section|$heading|$parameter|$recommended|$currentValue|$testResult|$scanDate" >> $fileName  }

        }
   }
   
    
  #default { write-output $data.Section }
 }
}

#Call for HIPPA Parameters
if($scanType -eq "HIPPA") { HIPPA_ParamCheck $importTable $filename }
