# Windows_HealthcheckScan
Windows Health Check Scan playbooks have been designed to perform security health check scan on Windows server 2012, Windows Server 2016 and 2019 hosts on the below section controls:
    password security
    File security
    network security violations 
    log Security
    Protecting Resources - OSR
    Protecting Resources - User Resources

Pre Requisites:

1.Technical Spec sheet should be converted into CSV with proper headers which are getting used in scan script to retrieve the data from TechSpec CSV.
2. Technical Spec CSV Mandatory Fields: 
        Section, SectionHeading, Parameter, Description, RecommendedValue.
(*** should follow the same heading values ***. Otherwise script can not read data from CSV ***)
Please take a reference of any of the techspec placed under TechSpecs folfer.Copy the heading and paste in the customer techspec CSV.

From Ansible Tower:

1. Fork the automation script from master GIT repository : https://github.ibm.com/lbotcha1/Windows_HealthcheckScan.git 
   (Note: Cental GIT repository will be updated soon )
2. update variable file based on the customer technical specification. ( Location: group_vars folder )  
3. Create hosts group from the base inventory in Ansible Tower ( eg. saac_target_endpoints in the master playbook -healthCheckScan.yml)   
4. Create a project in Ansible Tower.
5. Create a job Template to execute the playbook.  
6. Execute the job.
7. You can find the scan results in CSV format and currently it creates on End point.

Dependency: 
HealthCheck scan playbook needs Ansible version 2.3 or above to run the playbook along with Python 2.7 or above on the Ansible Controller.
WinRM should be enabled between Ansible Controller and Windows End Points. 

Ansible Setup guide: Currently Ansible can be run from any machine with Python 2 (versions 2.6 or 2.7) or Python 3 (versions 3.5 and higher) installed (Windows isn’t supported for the control machine). 

Ansible Installation guide: Refer the following URL to install Ansible latest version: http://docs.ansible.com/ansible/latest/intro_installation.html

Ansible documention URL: https://docs.ansible.com/

Developer:
Lavanya Botcha
lbotcha1@in.ibm.com
