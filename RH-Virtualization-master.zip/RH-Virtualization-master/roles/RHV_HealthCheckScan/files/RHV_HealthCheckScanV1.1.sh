#!/bin/bash -x
################################################################
#   Title    : Health check script for RHV                     #
#   Developer: Lavanya K Botcha (lbotcha1@in.ibm.com )         #
#   Platform : Linux (REDHAT Virutalization)		       #
#   Script   : Shell script                                    #
#   version  : 1.1                                             #
################################################################

clear
pause(){
  read -p "Press [Enter] key to continue..." fackEnterKey
}

#-----------------------------------------------------------------------------------
# Function: check_AdminAccount_status
# sectionID: KU.1.7.3
# Purpose: Internal Administrator User (admin@internal) for RHVM should be disabled.
#------------------------------------------------------------------------------------

check_AdminAccount_status () {
   section=("$@")   
   adminAccount_status=`ovirt-aaa-jdbc-tool user show admin | grep "^Account Disabled:" | awk -F":" '{print $2}'`
   if [ ! -z "$adminAccount_status" -a "$adminAccount" != " " ]; then
        if [ $adminAccount_status = "true" ]; then
            currentValue="Account Disabled=$adminAccount_status"
            testResult="OK"
        else
            currentValue="Account Disabled=$adminAccount_status"
            testResult="KO"
        fi
    else
        currentValue="admin Account Not Configured"
        testResult="KO"
    fi  
   [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid setting: $currentValue" || section[${#section[@]}]=" "
   section[${#section[@]}]=$testResult
   
   generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_SPICE_RDP
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.
#------------------------------------------------------------------------------------

check_SPICE_RDP () {
    section=("$@")
    configFile='/etc/libvirt/qemu.conf'
    if [ -e "$configFile" ]; then 
            spice_tls=`cat "$configFile" | grep -Ei '^spice_tls =|^spice_tls=' | awk -F"=" '{print $2}'`
            if [ $? -ne 0 ] || [ -z "$spice_tls" ]
            then
            currentValue="spice_tls=Not set" 
            testResult="KO"
            echo "SPICE PROTOCOL Not configured"
            elif [ $spice_tls -eq 1 ]; then
            currentValue="spice_tls=$spice_tls"
            testResult="OK"
            echo "SPICE PROTOCOL Configured"
            else
            currentValue="spice_tls=$spice_tls"
            testResult="KO"
            echo "SPICE PROTOCOL not configured"
            fi
    else
      currentValue="$configFile does not exist"
      testResult="KO"
    fi

    [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
    section[${#section[@]}]=$testResult

    generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_sVirt_protection
# sectionID: KU.1.4.1
# Purpose: Ensure sVirt is enabled  to isolate and protect guest VMs from each other.
#------------------------------------------------------------------------------------

check_sVirt_protection() {
    section=("$@")
    configFile="/etc/libvirt/qemu.conf"
    if [ -e "$configFile" ]; then 
        sVirt=`cat "$configFile" | grep -Ei '^security_driver =|^security_driver=' | awk -F"=" '{print $2}'`
        if [ $? -ne 0 ] || [ -z "$sVirt" ] 
        then
            currentValue="sVirt Protection Not configured"
            testResult="KO"
            echo "sVirt Protection not enabled"
        elif [ $sVirt = '"selinux"' ]
        then
            currentValue="security_driver=$sVirt"
            testResult="OK"
        else
            currentValue="security_driver=$sVirt"
            testResult="KO"
        fi
    else
      currentValue="$configFile does not exist."
      testResult="KO"    
    fi

     [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
     section[${#section[@]}]=$testResult

     generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_libVirt_status
# sectionID: KU.1.2.1
# Purpose: Ensure that libvirt is configured to generate audit records.
#------------------------------------------------------------------------------------

check_libVirt_status () {
    section=("$@")
    configFile="/etc/libvirt/libvirtd.conf"
    if [ -e "$configFile" ]; then 
        libVirt_status=`cat "$configFile" | grep -Ei '^audit_level=|audit_level =" | awk -F"=" '{print $2}'`
        if [ $? -ne 0 ] || [ -z "$libVirt_status" ]
        then
        currentValue="audit_level is not configured"
        testResult="KO" 
        elif [ $libVirt_status = 1 ]; then 
        currentValue="audit_level=$libVirt_status"
        testResult="OK"
        else 
        currentValue="audit_level=$libVirt_status"
        testResult="KO"
        fi
    else
        currentValue="$configFile doesn't Exist"
        testResult="KO"
    fi   
     [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
     section[${#section[@]}]=$testResult 

     generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_firewalld_service
# sectionID: KU.1.5.1
# Purpose: Ensure host firewall is enabled on RHV Hosts and RHV Manager VM.
#------------------------------------------------------------------------------------

check_firewalld_service () {
   section=("$@")
   firwalld_status=`systemctl is-enabled firewalld`
    if [ $? -ne 0 ] || [ -z "$firwalld_status" ]
    then
       currentValue="firewalld service not configured"
       testResult="KO"
    elif [ $firwalld_status = "enabled" ]; then
       firewalld_service=`systemctl status firewalld | grep -i "Active" | awk -F"[()]" '{print $2}'`
       if [ $firewalld_service = "running" ]; then
		currentValue="firewalld: $firewalld_service"
                testResult="OK"
       else
             currentValue="firewalld: $firewalld_service"
             testResult="KO"

       fi
   else
      currentValue="firewalld: $firewalld_status"
      testResult="KO"
   fi

   [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
   section[${#section[@]}]=$testResult
 
   generate_ScanReport "${section[@]}"
}

#---------------------------------------------------------------------------------------
# Function: check_secured_network_channels_RHVM
# sectionID: KU.1.4.3
# Purpose: Ensure that any remote management of the system takes place only over secured network channels.
#---------------------------------------------------------------------------------------

check_secured_network_channels_RHVM () {
  section=("$@")
  configFile="/etc/httpd/conf.d/ssl.conf"
  if [ -e "$configFile" ]; then
        sslProtocol_info=`cat "$configFile" | grep ^SSLProtocol`
        if [ $? -ne 0 ] || [ -z "$sslProtocol_info" ]
            then
            currentValue="Secure Network Channels(SSL/TLS) not configured"
            testResult="KO"
        elif [[ $sslProtocol_info == *"SSL"* ]] && [[ $sslProtocol_info == *"TLS"* ]]; then 
            currentValue="SSLProtocol info: $sslProtocol_info"
            testResult="OK"
        else
            currentValue="SSLProtocol info: $sslProtocol_info"
            testResult="OK"
        fi
    else
            currentValue="$configFile does not exist"
            testResult="KO"
    fi  
  section[3]='SSLProtocol all -SSLv2 -SSLv3 -TLSv1 -TLSv1.1'
  [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
  section[${#section[@]}]=$testResult
  
  generate_ScanReport "${section[@]}"
 }

#---------------------------------------------------------------------------------------
# Function: check_secured_network_channels_RHVH
# sectionID: KU.1.4.3
# Purpose: Ensure that any remote management of the system takes place only over secured network channels.
#---------------------------------------------------------------------------------------

check_secured_network_channels_RHVH () {
  section=("$@")
    
  output[0]='/etc/libvirt/libvirtd.conf:listen_tls = 1'
  output[1]='/etc/libvirt/libvirtd.conf:tls_port = "16514"'
  output[2]='/etc/libvirt/qemu.conf:spice_tls = 1'
  output[3]='/etc/vdsm/vdsm.conf:ssl = true'

  count=0
  failEntry=" "
  successEntry=" "

  check_File_Entries "${output[@]}"

  if [[ $count -gt 0 ]]; then
    testResult="KO"
  else
    testResult="OK"
  fi

  [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
  section[${#section[@]}]=$testResult
   
  generate_ScanReport "${section[@]}"  
 }

#---------------------------------------------------------------------------------------
# Function: check_SSL_TLS_Protocol_RHVM
# sectionID: KU.1.4.3
# Purpose: Ensure that any remote management of the system takes place only over secured network channels.
#---------------------------------------------------------------------------------------
  check_SSL_TLS_Protocol_RHVM () {
    section=("$@")
    
    configFile="/etc/ovirt-engine/ovirt-vmconsole-proxy-helper.conf.d/10-setup.conf"
    params[0]='ENGINE_CA=/etc/pki/ovirt-engine/apache-ca.pem'
    params[1]='TOKEN_CERTIFICATE=/etc/pki/ovirt-engine/certs/vmconsole-proxy-helper.cer'
    params[2]='TOKEN_KEY=/etc/pki/ovirt-engine/keys/vmconsole-proxy-helper.key.nopass'
    count=0
    failEntry=" "
    successEntry=" "
    
    check_config_Entries "${params[@]}" "$configFile"

    if [[ $count -gt 0 ]]; then
      testResult="KO"
    else
      testResult="OK"
    fi

    [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
    section[${#section[@]}]=$testResult
    
    generate_ScanReport "${section[@]}"  
        
  }

#---------------------------------------------------------------------------------------
# Function: check_SSL_TLS_Protocol_RHVH
# sectionID: KU.1.4.3
# Purpose: Ensure that any remote management of the system takes place only over secured network channels.
#---------------------------------------------------------------------------------------
  check_SSL_TLS_Protocol_RHVH () {
        section=("$@")

        configFile="/etc/libvirt/libvirtd.conf"

        params[0]='ca_file="/etc/pki/vdsm/certs/cacert.pem"'
        params[1]='cert_file="/etc/pki/vdsm/certs/vdsmcert.pem"'
        params[2]='key_file="/etc/pki/vdsm/keys/vdsmkey.pem"'

        count=0
        failEntry=" "
        successEntry=" "
        
        check_config_Entries "${params[@]}" "$configFile"
        
        echo "$count:$failEntry:$successEntry" >> /root/RHV/rhvLog

        if [[ $count -gt 0 ]]; then
        testResult="KO"
        else
        testResult="OK"
        fi

        [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
        section[${#section[@]}]=$testResult
        
        generate_ScanReport "${section[@]}"
  }

#---------------------------------------------------------------------------------------
# Function: check_connectionMethod
# sectionID: KU.1.4.2
# Purpose: The default connection method for the administration portal and VMportal is via HTTPS.
#---------------------------------------------------------------------------------------

check_connectionMethod (){
  section=("$@")

  configFile="/etc/ovirt-provider-ovn/conf.d/10-setup-ovirt-provider-ovn.conf"
  if [ -e "$configFile" ]; then

        connectionMethod=`cat "$configFile" | grep ^https-enabled | awk -F"=" '{print $2}'`
        if [ $? -ne 0 ] || [ -z "$connectionMethod" ]
        then
            currentValue="Connection Method (HTTP/HTTPS) not configured"
            testResult="KO"
        elif [ $connectionMethod = "true" ]; then
            currentValue="https-enabled: $connectionMethod"
            testResult="OK" 
        else
            currentValue="https-enabled: $connectionMethod"
            testResult="KO"
        fi
  else
        currentValue="$configFile does not exist"
        testResult="KO"
  fi   
        [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" " 
        section[${#section[@]}]=$testResult
        
        generate_ScanReport "${section[@]}"
      
}

#---------------------------------------------------------------------------------------
# Function: check_MAX_LOGIN_MINUTES
# sectionID: KU.1.4.4
# Purpose: MAX_LOGIN_MINUTES.
#---------------------------------------------------------------------------------------

check_MAX_LOGIN_MINUTES () {
   section=("$@")
   maxLoginMinutes=`ovirt-aaa-jdbc-tool settings show | awk '/MAX_LOGIN_MINUTES/{getline; print}' | awk -F": " '{print $2}'`
   if [ $? -ne 0 ] || [ -z "$maxLoginMinutes" ]
   then
       currentValue="MAX_LOGIN_MINUTES setting not configured"
       testResult="KO"
   elif [ $maxLoginMinutes = 10080 ]; then
      currentValue="MAX_LOGIN_MINUTES=$maxLoginMinutes"
      testResult="OK"
   else 
       currentValue="MAX_LOGIN_MINUTES=$maxLoginMinutes"
      testResult="KO"
   fi

   [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
   section[${#section[@]}]=$testResult

   generate_ScanReport "${section[@]}"
   #echo "$z|$fqdn|$ipAddress|$osName|KU.1.4.4|System Settings|MAX_LOGIN_MINUTES|$currentValue|$testResult|$c|$timestamp" >> $csvFile
}

#---------------------------------------------------------------------------------------
# Function: check_failed_login_attempts
# sectionID: KU.1.7.1
# Purpose: Set number of failed login attempts a user can perform before the user account is locked.
#---------------------------------------------------------------------------------------

check_failed_login_attempts () {
   section=("$@")
   failedLoginAttempts=`ovirt-aaa-jdbc-tool settings show | awk '/MAX_FAILURES_SINCE_SUCCESS/{getline; print}' | awk -F": " '{print $2}'`
   if [ $? -ne 0 ] || [ -z "$failedLoginAttempts" ]
   then
       currentValue="MAX_FAILURES_SINCE_SUCCESS setting not configured"
       testResult="KO"
   elif [ $failedLoginAttempts = 3 ]; then
      currentValue="MAX_FAILURES_SINCE_SUCCESS=$failedLoginAttempts"
      testResult="OK"
   else
     currentValue="MAX_FAILURES_SINCE_SUCCESS=$failedLoginAttempts"
     testResult="KO"
   fi

   [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue" || section[${#section[@]}]=" "
   section[${#section[@]}]=$testResult

   generate_ScanReport "${section[@]}"
}  

#---------------------------------------------------------------------------------------
# Function: check_direct_access_to_hosts
# sectionID: KU.1.4.5
# Purpose: Restrict direct access to RHV Host machine to only system administrators.
#---------------------------------------------------------------------------------------

check_direct_access_to_hosts () {
 section=("$@")
 sshd_status=`systemctl is-enabled sshd`
    if [ $? -ne 0 ] || [ -z "$sshd_status" ]
    then
       currentValue="sshd service not configured"
       testResult="OK"
    elif [ $sshd_status = "enabled" ]; then
       echo "in 1"
       sshd_service=`systemctl status sshd | grep -i "Active" | awk -F"[()]" '{print $2}'`
       if [ $sshd_service = "running" ]; then
                currentValue="sshd: $sshd_service"
                testResult="KO"
       echo "in 2"
       else
       echo " in 3"
             currentValue="sshd: $sshd_service"
             testResult="OK"

       fi
   else
      currentValue="sshd: $sshd_status"
      testResult="OK"
   fi
   [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $currentValue. It should be disabled" || section[${#section[@]}]=" "
   section[${#section[@]}]=$testResult

   generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_SSL_TLS_Configuration_OVIRT_RHVM
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.
#------------------------------------------------------------------------------------
check_SSL_TLS_Configuration_OVIRT_RHVM () {
        section=("$@")
        
        configFile="/etc/ovirt-provider-ovn/conf.d/10-setup-ovirt-provider-ovn.conf"
        
        params[0]='ovirt-host=https://rhv-manager.mcmslab.com:443'
        params[1]='ovirt-ca-file=/etc/pki/ovirt-engine/apache-ca.pem'
        params[2]='port-security-enabled-default=True'
        
        count=0
        failEntry=" "
        successEntry=" "

        section[${#section[@]}]=$configFile:$( IFS=$';'; echo "${params[*]}" )
        
        check_config_Entries "${params[@]}" "$configFile"

        if [[ $count -gt 0 ]]; then
            testResult="KO"
        else
            testResult="OK"
        fi

        [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
        section[${#section[@]}]=$testResult
                
        generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_SSL_TLS_Configuration_OVN_RHVM
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.
#------------------------------------------------------------------------------------
check_SSL_TLS_Configuration_OVN_RHVM () {
  section=("$@")
  configFile="/etc/ovirt-provider-ovn/conf.d/10-setup-ovirt-provider-ovn.conf"
  params[0]='https-enabled=true'
  params[1]='ssl-cacert-file=/etc/pki/ovirt-engine/ca.pem'
  params[2]='ssl-cert-file=/etc/pki/ovirt-engine/certs/ovirt-provider-ovn.cer'
  params[3]='ssl-key-file=/etc/pki/ovirt-engine/keys/ovirt-provider-ovn.key.nopass'

  count=0
  failEntry=" "
  successEntry=" "
  
  section[${#section[@]}]=$configFile:$( IFS=$';'; echo "${params[*]}" )

        check_config_Entries "${params[@]}" "$configFile"

        if [[ $count -gt 0 ]]; then
            testResult="KO"
        else
            testResult="OK"
        fi

        [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
        section[${#section[@]}]=$testResult
                
        generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_SSL_TLS_Configuration_Engine_RHVM
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.
#------------------------------------------------------------------------------------
check_SSL_TLS_Configuration_Engine_RHVM () {
  section=("$@")
  configFile="/etc/ovirt-engine/engine.conf.d/10-setup-pki.conf"
  params[0]='ENGINE_PKI="/etc/pki/ovirt-engine'
  params[1]='ENGINE_PKI_CA="/etc/pki/ovirt-engine/ca.pem"'
  params[2]='ENGINE_PKI_ENGINE_CERT="/etc/pki/ovirt-engine/certs/engine.cer"'
  params[3]='ENGINE_PKI_TRUST_STORE="/etc/pki/ovirt-engine/.truststore"'
  params[4]='ENGINE_PKI_ENGINE_STORE="/etc/pki/ovirt-engine/keys/engine.p12"'
  
  count=0
  failEntry=" "
  successEntry=" "

  section[${#section[@]}]=$configFile:$( IFS=$';'; echo "${params[*]}" )

  check_config_Entries "${params[@]}" "$configFile"

  if [[ $count -gt 0 ]]; then
    testResult="KO"
  else
    testResult="OK"
  fi
  
  [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
  section[${#section[@]}]=$testResult
                
  generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_SSL_TLS_Configuration_websocket_RHVM
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.
#------------------------------------------------------------------------------------
check_SSL_TLS_Configuration_websocket_RHVM () {
  section=("$@")
  configFile="/etc/ovirt-engine/ovirt-websocket-proxy.conf.d/10-setup.conf"
  websocket_params[0]='SSL_CERTIFICATE=/etc/pki/ovirt-engine/certs/websocket-proxy.cer'
  websocket_params[1]='SSL_KEY=/etc/pki/ovirt-engine/keys/websocket-proxy.key.nopass'
  websocket_params[2]='CERT_FOR_DATA_VERIFICATION=/etc/pki/ovirt-engine/certs/engine.cer'
  websocket_params[3]='SSL_ONLY=True'

  count=0
  failEntry=" "
  successEntry=" "

  section[${#section[@]}]=$configFile:$( IFS=$';'; echo "${websocket_params[*]}" )
  
  check_config_Entries "${websocket_params[@]}" "$configFile"

  if [[ $count -gt 0 ]]; then
    testResult="KO"
  else
    testResult="OK"
  fi

  [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
  section[${#section[@]}]=$testResult
        
  generate_ScanReport "${section[@]}"
}

#-----------------------------------------------------------------------------------
# Function: check_SSL_TLS_Configuration_Image_RHVM
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.
#------------------------------------------------------------------------------------
check_SSL_TLS_Configuration_Image_RHVM () {
  section=("$@")
  
  configFile="/etc/ovirt-imageio-proxy/ovirt-imageio-proxy.conf"
  params[0]="use_ssl = true"
  params[1]="ssl_key_file = /etc/pki/ovirt-engine/keys/apache.key.nopass"
  params[2]="ssl_cert_file = /etc/pki/ovirt-engine/certs/apache.cer"
  params[3]="engine_cert_file = /etc/pki/ovirt-engine/certs/engine.cer"
  params[4]="engine_ca_cert_file = /etc/pki/ovirt-engine/ca.pem"

  count=0
  failEntry=" "
  successEntry=" "

  section[${#section[@]}]=$configFile:$( IFS=$';'; echo "${params[*]}" )

  check_config_Entries "${params[@]}" "$configFile"
  if [[ $count -gt 0 ]]; then
    testResult="KO"
  else
    testResult="OK"
  fi

  [[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
  section[${#section[@]}]=$testResult
        
  generate_ScanReport "${section[@]}"
}

#----------------------------------------------------------------------------------------------------------------------------
# Function: check_OvirtEngine_Permissions
# sectionID: KU.2.1.1
# Purpose: SSL/TLS  should be enabled for all of the SPICE communication channels.#
#----------------------------------------------------------------------------------------------------------------------------
check_OvirtEngine_Permissions (){
section=("$@")
count=0

# Check the permissions for directory paths 

  for path in "/etc/pki" "/etc/pki/ovirt-engine"
  do
    if [ -d $path ]; then

    permcheckdir=$(find $path -type d -exec stat -c '%a' '{}' +)

    if [[ $permcheckdir != *755 ]]
    then
        count=`expr $count + 1`
        echo "$path directory permissions are not standard" >> /root/RHV/rhvLog
    else
        echo "$path directory permissions are correct" >> /root/RHV/rhvLog
    fi
    fi
  done

for path in $(find /etc/pki/ovirt-engine/ -print)
do
    if [ -f $path ]; then
     if [[ $path == *"/etc/pki/ovirt-engine/keys"* ]]||[[ $path == *"/etc/pki/ovirt-engine/private" ]]; then
    permcheckfile=$(find $path -type f -exec stat -c '%a' '{}' +)
        if [[ $permcheckfile != *640 ]]
        then
           count=`expr $count + 1`
          echo "$path file permissions are not standard" >> /root/RHV/rhvLog
        else 
          echo "$path file permissions are correct" >> /root/RHV/rhvLog
        fi
     fi

     if [[ $path == *"/etc/pki/ovirt-engine/certs"* ]]||[[ $path == *"/etc/pki/ovirt-engine/requests"* ]]; then
    permcheckfile=$(find $path -type f -exec stat -c '%a' '{}' +)
        if [[ $permcheckfile != *644 ]]
        then
          count=`expr $count + 1`
          echo "$path file permissions are not standard" >> /root/RHV/rhvLog
        else
          echo "$path file permissions are correct" >> /root/RHV/rhvLog
        fi
     fi

   fi
    if [ -d $path ]; then

    permcheckdir=$(find $path -type d -exec stat -c '%a' '{}' +)

    if [[ $permcheckdir != *755 ]]
    then
        count=`expr $count + 1`
        echo "$path directory permissions are not standard" >> /root/RHV/rhvLog
    else
        echo "$path directory permissions are correct" >> /root/RHV/rhvLog
    fi
    fi
 done
echo $count
if [[ $count -gt 0 ]]; then
  testResult="KO"
  failEntry="$count path permisisons are not standard"
else
   testResult="OK"
fi
[[ $testResult = "KO" ]] && section[${#section[@]}]="Invalid Setting: $failEntry" || section[${#section[@]}]=" "
section[${#section[@]}]=$testResult

generate_ScanReport "${section[@]}"

}

#------------------------------------------------------------------------------
#Function: check_config_Entries
#Purpose: it Checkes
#  1. Whether config File exists or not.
#  2. Iterate over key params and check whether the mentioned files are present in the system or not.
#  3. If the key Param value is either a URL or True or False, then it will check the standard comparision with the requirement.
#  Return: 
#    failEntry : Entries which are validated Failed
#    successEntry: Entries with are validated Success     
#    count: count of the failed Entries.
#------------------------------------------------------------------------------
check_config_Entries () {
params=("$@")
((last_idx=${#params[@]} - 1))
    configFile=${params[last_idx]}
    unset params[last_idx]

#echo "$configFile"
#echo "${params[@]}"

if [ -e "$configFile" ]; then
for item in "${params[@]}"
do
   key=`cut -d "=" -f 1 <<< $item`
   keyParam=`grep "^$key=" $configFile`
   if [ ! -z "$keyParam" -a "$keyParam" != " " ]; then
     echo "loop 1" >> /root/RHV/rhvLog
     if ! [[ "$keyParam" =~ "https" || "$keyParam" =~ "True" || "$keyParam" =~ "False" || "$keyParam" =~ "true" || "$keyParam" =~ "false" ]]; then
       echo "Loop 1.1" >> rhvLog
       file=`cut -d "=" -f2- <<< $keyParam|sed 's/"//g'|sed 's/ //g'`
       echo "File: $file" >> /root/RHV/rhvLog
       if ! [[ -f $file || -d $file ]]; then
         echo "Loop 1.2" >> /root/RHV/rhvLog
         failEntry+="$keyParam"
         count=`expr $count + 1`
       else
         successEntry+="$keyParam"
       fi
     else
         if [ "$keyParam" == "$item" ]; then
          echo "loop 1.3" >> /root/RHV/rhvLog
          echo "$keyParam" >> /root/RHV/rhvLog
          successEntry+="$keyParam"
         else
           echo "loop 1.4" >> rhvLog
           failEntry+="$keyParam"
           count=`expr $count + 1`
         fi
     fi
   else
     echo "loop 2" >> rhvLog
     failEntry+=" $key is not configured "
     count=`expr $count + 1`
   fi
done
else
#  echo "$configFile doesn't Exists"
  failEntry+=" configFile doesn't Exists "
  count=`expr $count + 1`
fi

   echo "Fail: $failEntry" >> /root/RHV/rhvLog
   echo "Success: $successEntry" >>/root/RHV/rhvLog
   echo "Count: $count" >>/root/RHV/ rhvLog

   unset params
}

#-------------------------------------------------------------------
#Function: check_File_Entries
#Purpose:
#Return:
#-------------------------------------------------------------------
check_File_Entries () {
 params=("$@")

 for item in "${params[@]}"
 do
  configFile=`cut -d ":" -f 1 <<< $item`
  keyItem=`cut -d ":" -f2 <<< $item`
  echo "$configFile"
  echo "$keyItem"

  key=`cut -d "=" -f 1 <<< $keyItem`
  echo "$key"

  if [[ -e $configFile ]]; then
  keyParam=`grep "^$key=" $configFile`
   if [ ! -z "$keyParam" -a "$keyParam" != " " ]; then
     echo "loop 1" >> /root/RHV/rhvLog
     if [ "$keyParam" == "$keyItem" ]; then
          echo "loop 1.3"
          echo "$keyParam"
          successEntry+="$keyParam"
     else
           echo "loop 1.4"
           failEntry+="$keyParam"
           count=`expr $count + 1`
     fi
   else
     echo "loop 2"
     failEntry+=" $key is not configured "
     count=`expr $count + 1`
   fi
  else
   echo "$configFile doesn't Exists"
   failEntry+=" configFile doesn't Exists "
   count=`expr $count + 1`
  fi
done 
   echo "Fail: $failEntry" >> /root/RHV/rhvLog
   echo "Success: $successEntry" >>/root/RHV/rhvLog
   echo "Count: $count" >>/root/RHV/ rhvLog

#unset params  
}

#--------------------------------------****THE BELOW COVERED IN RHEL HEALTH CHECK SCAN****--------------------------------------------
check_SELinuxtype() {
    checkEnforce=`getenforce`
    if [ $? -ne 0 ] || [ -z "$checkEnforce" ]; then
       currentValue="SELINUX is not Enforcing"
       testResult="No"
    elif [ $checkEnforce = "Enforcing" ]; then
           SELinuxtype=`cat /etc/selinux/config | grep ^SELINUXTYPE | awk -F"=" '{print $2}'`
           if [ $SELinuxtype = "targeted" ] || [ $SELinuxtype = "mls" ]; then
              currentValue="SELINUXTYPE=$SELinuxtype"
              testResult="Yes"    
           else
              currentValue="SELINUXTYPE=$SELinuxtype" 
              testResult= "No"
           fi
    fi		
echo "$z|$fqdn|$ipAddress|$osName|1.1.6|System Settings|Ensure SELinuxtype of Minimum is not used on  on RHVM RHV Hosts and Gluster nodes.|$currentValue|$testResult|$c|$timestamp" >> $csvFile
}

check_auditd_service () {
   auditd_status=`systemctl is-enabled auditd`
   if [ $? -ne 0 ] || [ -z "$auditd_status" ]; then
       currentValue="auditd is not configured"
       testResult="No"
   elif [ $auditd_status = "enabled" ]; then 
     currentValue="auditd: $auditd_status"
     testresult="Yes"
   else
     currentValue="auditd: $auditd_status"
     testresult="No"
   fi
 echo "$z|$fqdn|$ipAddress|$osName|1.1.7|Logging|Ensure auditd service is enabled|$currentValue|$testResult|$c|$timestamp" >> $csvFile
  # auditd_service=`systemctl status auditd | grep -i "Active" | awk -F"[()]" '{print $2}'`
  # if [ $auditd_service = "running" ]; then 
  #  echo "Yes"
  # else  
  #  echo "No"
  #	echo "$auditd_service"
  # fi	

}

check_IPTables_service () {
   ipTables_status=`systemctl is-enabled iptables`
    if [ $? -ne 0 ] || [ -z "$ipTables_status" ] 
    then
       currentValue="iptables service not configured"
       testResult="No"
    elif [ $ipTables_status = "enabled" ]; then 
     ipTables_service=`systemctl status iptables | grep -i "Active" | awk -F"[()]" '{print $2}'`
     if [ $ipTables_service = "running" ]; then
	currentValue="iptables: $ipTables_service"
        testResult="Yes"
     else
       currentValue="iptables: $ipTables_service"
       testResult="No"
     fi
    else
      currentValue="iptables: $ipTables_status"
      testResult="No" 
   fi  
   echo "$z|$fqdn|$ipAddress|$osName|1.1.9|System Settings|Ensure IPTables is enabled on RHV Hosts and RHV Manager|$currentValue|$testResult|$c|$timestamp" >> $csvFile
}
#------------------------------------------------------****END: RHEL****----------------------------------------------------------------------------------------

generate_ScanReport () {
  param=("$@")
  echo "$ecm_version,$sourceName,$accountID,$accountName,$country,$hostname,$ipAddress,$osName,$osVersion,$scanType,$applicationCategory,$applicationCategory,$instanceName,$timestamp,$policyName,$policyVersion,$policyItem,${section[5]},$nonComplianceSeverity,${section[0]},${section[2]},${section[3]},${section[4]},$submitter,$performedBy,$externalReferenceDocument,$externalSequenceNumber" >> "$csvFile"   
}

source hc_scan_parameter.sh

accountID="$1"
accountName="$2"

#Command to check whether the host is RHV-M / RHV-Hosts
 checkServerInfo=`virsh echo "HelloGuest"`
 if [ $? -ne 0 ] || [ -z "$checkServerInfo" ]
    then
       echo "virsh command doesnt work for RHV-M"
       hostServer="RHV-M"
 elif [ $checkServerInfo = "HelloGuest" ]
 then
   hostServer="RHV-Host"
 else
   hostServer="RHV-M"
 fi   

case "$hostServer" in 
  "RHV-M") echo "RedHat Virtualization Manager"
           #check_libVirt_status "${libvirt[@]}" - Check only required for RHV-H
           check_connectionMethod "${connectionMethod[@]}"
           check_secured_network_channels_RHVM "${encryptionMethod[@]}"
           check_SSL_TLS_Protocol_RHVM "${encryptionCerts_RHVM[@]}"
           check_MAX_LOGIN_MINUTES "${maxLoginMinutes[@]}"
#           check_direct_access_to_hosts "${restrictAccessToHost[@]}"
           check_firewalld_service "${firewallCheck[@]}"
           check_failed_login_attempts "${failedLoginAttempts[@]}"
           check_AdminAccount_status "${disableDefaultAdmin[@]}"
           check_OvirtEngine_Permissions "${pathPermissions[@]}"
           check_SSL_TLS_Configuration_OVIRT_RHVM "${enableSSL[@]}" 
           check_SSL_TLS_Configuration_OVN_RHVM "${enableSSL[@]}" 
           check_SSL_TLS_Configuration_Engine_RHVM "${enableSSL[@]}" 
           check_SSL_TLS_Configuration_websocket_RHVM "${enableSSL[@]}" 
           check_SSL_TLS_Configuration_Image_RHVM "${enableSSL[@]}" ;; 

  "RHV-Host") echo "RedHat Virtualization Host" 
              check_libVirt_status "${libvirt[@]}"
              check_sVirt_protection "${sVirt[@]}"
              check_secured_network_channels_RHVH "${encryptionMethod[@]}"
              check_SSL_TLS_Protocol_RHVH "${encryptionCerts_RHVH[@]}" 
              check_direct_access_to_hosts "${restrictAccessToHost[@]}"
              check_firewalld_service "${firewallCheck[@]}"
              check_SPICE_RDP "${enableSPICE[@]}" ;;
esac

sed -i 1i"Version number,Source name,Customer ID,Customer name,Country,Host name,IP address,OS name,OS version,ScanType,ApplicationCategory,Applicationname,InstanceName,Date of the health check,PolicyName,PolicyVersion,PolicyItem,Health Check Result,Non compliance severity,Check name,Check description,Agreed to settings,Reason of the non compliance,Submitter name,Performed by,External reference document,External sequence number" "$csvFile"

chmod 644 $csvFile
mv $csvFile ANSIBLE.`hostname`.csv
