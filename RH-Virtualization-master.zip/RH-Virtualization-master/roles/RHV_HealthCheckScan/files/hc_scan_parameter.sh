#!/bin/bash -x
#---------------------------------------------------------------------
# Scan Report Standard Fields
#---------------------------------------------------------------------

ecm_version=3
sourceName="ANS"  
country=""
osVersion=""
scanType="O"
applicationCategory=""
applicationName=""
instanceName=""
policyName="ITSS"
policyVersion="1.0"
policyItem="ITSS-OS"
nonComplianceSeverity="Critical"
submitter="Not Provided"
performedBy="Not provided"
externalReferenceDocument="Nci"
externalSequenceNumber="1"

#--------------------------------------------------------------------
# Information about System
#--------------------------------------------------------------------

accountName="Account-ABC"
accountID="AccountID"
scanVersion="V1.0"
techSpecVersion="RHV_V1.0"

hostname=`hostname`
ipAddress=`hostname -i`
fqdn=`hostname --fqdn`
timestamp=`date '+%Y-%m-%d-%H%M%S%6N'`
csvFile=`hostname`_`date "+%m%d%Y"`.csv
#osName=`lsb_release -a | grep -w Description | cut -d':' -f2 | awk '{$1=$1};1'`
osName=`grep '^NAME' /etc/os-release | awk -F"=" '{print $2}'`
osVersion=`grep '^VERSION_ID=' /etc/os-release | awk -F"=" '{print $2}'`
dateOfHealthCheck=`date | awk '{print $1"-"$2"-"$3"-"$6"-"$4}'`
#-------------------------------------------------------------------

#--------------------------------------------------------------------
# section Params
#--------------------------------------------------------------------
#KU.1.2.1 - Ensure that libvirt is configured to generate audit records
libvirt[0]="KU.1.2.1"
libvirt[1]="Logging"
libvirt[2]="Ensure that libvirt is configured to generate audit records"
libvirt[3]="Check the configuration file /etc/libvirt/libvirtd.conf for the audit_level parameter: audit_level=1"

sVirt[0]="KU.1.4.1"
sVirt[1]="System Settings"
sVirt[2]="Ensure sVirt is enabled  to isolate and protect guest VMs from each other"
sVirt[3]="Check and ensure that the  /etc/libvirt/qemu.conf file has the following configuration:  security_driver = 'selinux'"

connectionMethod[0]="KU.1.4.2"
connectionMethod[1]="System Settings"
connectionMethod[2]="The default connection method for the administration portal and VMportal is via HTTPS."
connectionMethod[3]="The administration and VM portal should not allow HTTP connection and only HTTPS should be supported."

output[0]='/etc/libvirt/libvirtd.conf:listen_tls = 1'
output[1]='/etc/libvirt/libvirtd.conf:tls_port = "16514"'
output[2]='/etc/libvirt/qemu.conf:spice_tls = 1'
output[3]='/etc/vdsm/vdsm.conf:ssl = true'

encryptionMethod[0]="KU.1.4.3"
encryptionMethod[1]="System Settings"
encryptionMethod[2]="Ensure that any remote management of the system takes place only over secured network channels."
encryptionMethod[3]='/etc/libvirt/libvirtd.conf:listen_tls = 1;/etc/libvirt/libvirtd.conf:tls_port = "16514";/etc/libvirt/qemu.conf:spice_tls = 1;/etc/vdsm/vdsm.conf:ssl = true'

encryptionCerts_RHVM[0]="KU.1.4.3"
encryptionCerts_RHVM[1]="System Settings"
encryptionCerts_RHVM[2]="Ensure that any remote management of the system takes place only over secured network channels."
encryptionCerts_RHVM[3]='/etc/ovirt-engine/ovirt-vmconsole-proxy-helper.conf.d/10-setup.conf:ENGINE_CA=/etc/pki/ovirt-engine/apache-ca.pem;TOKEN_CERTIFICATE=/etc/pki/ovirt-engine/certs/vmconsole-proxy-helper.cer;TOKEN_KEY=/etc/pki/ovirt-engine/keys/vmconsole-proxy-helper.key.nopass'

encryptionCerts_RHVH[0]="KU.1.4.3"
encryptionCerts_RHVH[1]="System Settings"
encryptionCerts_RHVH[2]="Ensure that any remote management of the system takes place only over secured network channels."
encryptionCerts_RHVH[3]='/etc/libvirt/libvirtd.conf:ca_file="/etc/pki/vdsm/certs/cacert.pem";cert_file="/etc/pki/vdsm/certs/vdsmcert.pem";key_file="/etc/pki/vdsm/keys/vdsmkey.pem"'

maxLoginMinutes[0]="KU.1.4.4"
maxLoginMinutes[1]="System Settings"
maxLoginMinutes[2]="MAX_LOGIN_MINUTES"
maxLoginMinutes[3]="#ovirt-aaa-jdbc-tool settings set --name=MAX_LOGIN_MINUTES –value=30(as per customer policy)"

restrictAccessToHost[0]="KU.1.4.5"
restrictAccessToHost[1]="System Settings"
restrictAccessToHost[2]="Restrict direct access to RHV Host machine to only system administrators"
restrictAccessToHost[3]="sshd status should be disabled"

firewallCheck[0]="KU.1.5.1"
firewallCheck[1]="Network Settings"
firewallCheck[2]="Ensure host firewall is enabled on RHV Hosts and RHV Manager"
firewallCheck[3]="Please run #systemctl status firewalled. The service should be running .If the service is stopped start it  #systemctl start firewalled."
	
failedLoginAttempts[0]="KU.1.7.1"
failedLoginAttempts[1]="Identify and Authenticate Users"
failedLoginAttempts[2]="Set number of failed login attempts a user can perform before the user account is locked"
failedLoginAttempts[3]="#ovirt-aaa-jdbc-tool settings set --name=MAX_FAILURES_SINCE_SUCCESS --value=3 (change this as per customer requirement"

#KU.1.7.2 - can not be automated

disableDefaultAdmin[0]="KU.1.7.3"
disableDefaultAdmin[1]="Identify and Authenticate Users"
disableDefaultAdmin[2]="Internal Administrator User '(admin@internal)' for RHVM should be disabled."
disableDefaultAdmin[3]="#ovirt-aaa-jdbc-tool user show admin. The output should show 'Account Disabled: True'"

enableSPICE[0]="KU.2.1.1"
enableSPICE[1]="Encryption"
enableSPICE[2]="SSL/TLS should be enabled for all of the SPICE communication channels"
enableSPICE[3]="The /etc/libvirt/qemu.conf file on all RHV hosts should have the following parameter set: spice_tls = 1"

enableSSL[0]="KU.2.1.1"
enableSSL[1]="Encryption"
enableSSL[2]="SSL TLS should be enabled for all of the SPICE communication channels"
#enableSSL[3]='/etc/ovirt-engine/engine.conf.d/10-setup-pki.conf:ENGINE_PKI="/etc/pki/ovirt-engine";ENGINE_PKI_CA="/etc/pki/ovirt-engine/ca.pem";ENGINE_PKI_ENGINE_CERT="/etc/pki/ovirt-engine/certs/engine.cer";ENGINE_PKI_TRUST_STORE="/etc/pki/ovirt-engine/.truststore";ENGINE_PKI_ENGINE_STORE="/etc/pki/ovirt-engine/keys/engine.p12"'

pathPermissions[0]="KU.2.1.1"
pathPermissions[1]="Encryption"
pathPermissions[2]="SSL TLS should be enabled for all of the SPICE communication channels"
pathPermissions[3]="The permission for the /etc/pki and the /etc/pki/ovirt-engine directory/sub directories must remain as the default-755.All Files should be either 640 /644"
