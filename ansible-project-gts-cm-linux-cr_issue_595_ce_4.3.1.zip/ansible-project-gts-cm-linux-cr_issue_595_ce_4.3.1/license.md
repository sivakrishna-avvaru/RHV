**NOTICE**

# IBM - LIMITED USE

This Software is IBM Confidential and copyright property of IBM, it should not be shared or distributed beyond IBM employees. 

This code should be used for conducting IBM's business or for purposes authorized by IBM management.

It is mandatory to comply with all the requirements listed in the applicable security policy and only process or store the data classes approved for this asset type.

If used at a customer site, it should be kept in an area secured to only IBM access.

Use is subject to audit at any time by IBM management.

Link to the IBM Privacy Statement: https://www.ibm.com/privacy
