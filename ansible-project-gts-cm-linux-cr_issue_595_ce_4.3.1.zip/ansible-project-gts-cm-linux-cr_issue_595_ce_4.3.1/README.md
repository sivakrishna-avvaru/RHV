# ansible-project-gts-cm-linux
![stability-stable](https://img.shields.io/badge/stability-stable-green.svg)

[Ansible](https://www.ansible.com/) is a configuration management tool, similar to [BigFix](https://www.Bigfix.com/). It allows for performing logical configuration of infrastructure components, such as servers and network switches. The configuration files in this repository can act as a template for your own Ansible secuirty and compliance projects, in order to get you started quickly. Once you've customized the configuration files then new servers can be health checked quickly.

GCM is the strategic GTS secondary controls solution for security health checking of servers adhering to ITSS/CSD security standards.  

**IMPORTANT USAGE NOTICES**

GTS only supports the currently published release ("N") and the previous release ("N-1") of GCM content.  Accounts should not expect more than advisory "best effort" support for back level versions and are strongly advised to upgrade to the latest major GCM release (ie. v4.x.0) when it becomes available.

## Using this repository

Please see the user Guide listed here:

[GCM For Ansible User Guide](https://apps.na.collabserv.com/wikis/home?lang=en-us#!/wiki/We6826dbd1b72_4cc5_a37f_3c542dacdc64/page/Security%20Health%20Check)

## Requirements

* Ansible Tower and a W3 ID is required to access this repo.
* Standard Ansible prerequisities.

## Dependencies

* Unix servers require 'unzip' to be installed to be able to 'unarchive' jre downloaded form the BDS Server, when use_bds: true.

# Results from execution

Return Code | Success of execution| Execution had an effect on target machine     | Comments
------------|------------|--------------------------------------------------------|---------
0           | True       | False  | All Ok
1           | False      | False  | HCLauncher Error
2           | False      | False  | Collector Error
3           | False      | False  | Collector and HCLauncher Error
4           | False      | False  | SQL Error
5           | False      | False  | SQL and HCLauncher Error
6           | False      | False  | SQL and Collector Error
7           | False      | False  | SQL and Collector and HCLauncher Error
8           | True       | False  | Remote Collector Error
9           | False      | False  | Ansible Scan task timeout Error
194         | True       | False  | Server Requires a reboot (UNIX Policies only)
999         | True       | False  | GPO Controlled setting (Windows Policies only)
3010        | True       | False  | Server Requires a reboot (Windows Policies only)

```
Exit code can be checked from standard out or from HCLauncher log.
```

# Known problems and limitations

* N/A


## License

See [license.md](https://github.ibm.com/Continuous-Engineering/ansible-project-gts-cm-linux/blob/master/license.md)

## Author Information
Author: GCM Dev Team
