param( $osr_path,$generalUsers )

$folder = $osr_path
$user = $generalUsers

$acl = Get-ACL -Path "$folder"
$acl.SetAccessRuleProtection($True, $True)
Set-Acl -Path "$folder" -AclObject $acl
icacls "$folder" /remove:g $user
