#!/bin/bash

#AD.1.1.6.0
st1=`cat /etc/pam.d/password-auth |grep ^account |head -1 |grep ^account |grep required |grep pam_tally2.so`
if [ $? -eq 0 ]
then
	echo "Required entry exist at first line of the account section in /etc/pam.d/password-auth"
else
	sk=`cat /etc/pam.d/password-auth |grep ^account |head -1`
	sed -i "/$sk/i account     required      pam_tally2.so" /etc/pam.d/password-auth
	echo "Entry 'account required pam_tally2.so' added in /etc/pam.d/password-auth"
fi

st2=`cat /etc/pam.d/system-auth |grep ^account |head -1 |grep ^account |grep required |grep pam_tally2.so`
if [ $? -eq 0 ]
then
	echo "Required entry exist at first line of the account section in /etc/pam.d/password-auth"
else
	sk=`cat /etc/pam.d/system-auth |grep ^account |head -1`
	sed -i "/$sk/i account     required      pam_tally2.so" /etc/pam.d/system-auth
	echo "Entry 'account required pam_tally2.so' added in /etc/pam.d/system-auth"
fi

st3=`cat /etc/pam.d/password-auth |grep ^auth |head -1 |grep ^auth |grep required |grep pam_tally2.so |grep deny=5`
if [ $? -eq 0 ]
then
	echo "Required entry exist at first line of the account section in /etc/pam.d/password-auth"
else
	sk=`cat /etc/pam.d/password-auth |grep ^auth |head -1`
	sed -i "/$sk/i auth        required      pam_tally2.so deny=5" /etc/pam.d/password-auth
	echo "Entry 'auth required pam_tally2.so deny=5' added in /etc/pam.d/password-auth"
fi

st4=`cat /etc/pam.d/system-auth |grep ^auth |head -1 |grep ^auth |grep required |grep pam_tally2.so |grep deny=5`
if [ $? -eq 0 ]
then
	echo "Required entry exist at first line of the account section in /etc/pam.d/system-auth"
else
	sk=`cat /etc/pam.d/system-auth |grep ^auth |head -1`
	sed -i "/$sk/i auth        required      pam_tally2.so deny=5" /etc/pam.d/system-auth
	echo "Entry 'auth required pam_tally2.so deny=5' added in /etc/pam.d/system-auth"
fi