#AD.1.5.8.1,AD.1.5.8.2,AD.1.5.8.3,AD.1.5.8.4,AD.1.5.8.5,AD.1.5.8.6,AD.1.5.8.7,AD.1.5.8.8,AD.1.5.9.1,AD.1.5.9.2,AD.1.5.9.3,AD.1.5.9.4,AD.1.5.9.5,AD.1.5.9.6,AD.1.5.9.7,AD,1.5.9.8,AD.1.5.9.9,AD.1.5.9.10,AD.1.5.9.11,AD.1.5.9.12,AD.1.5.9.13,AD.1.5.9.14,AD.1.5.9.15,AD.1.5.9.16,AD.1.5.9.17;AD.1.5.9.23;AD.1.5.9.24
echo "chargen,daytime,discard,echo,telnet,ftp,rlogin,rsh,finger,systat,rwho,netstat,echo,chargen,rstatd,tftp,rwalld,rusersd,discard,daytime,bootps,finger,sprayd,pcnfsd,netstat,rwho,cmsd,dtspcd,ttdbserver" >temp
tr "," "\n" < temp > temp1
for i in `cat temp1`
do 
ls /etc/xinetd.d |grep $i >services1
sl=`cat services1 |wc -l`
if [ $sl -gt 0 ]
then
sk=`cat /etc/xinetd.d/$i |grep -v '#' |grep -v '^$' |grep disable |awk -F= '{print $2}' |sed -e 's/ //g'`
	if [ "$sk" == "no" ]
	then
		sed -i 's/disable.*/disable         = yes/g' /etc/xinetd.d/$i
		echo "Service $i is disabled in /etc/xinetd.d"
	fi
else
echo "No service file $i not found in /etc/xinetd.d"
fi
done
rm -rf services1 temp temp1
