<#
    .SYNOPSIS
        Scripts to fill the MHC Template with Actual values in the ESXi hosts
        Compares the Actual values with IBM Recommended values and provides the Finding Level


#>


$target = Read-Host "Please enter the target server FQDN or IP address "
$username = Read-Host "Enter Your IBM Mail id "
$filepath = Read-Host "Enter the Location of the VMware ESXi HC Template with FileName Included "


Function MHC_AutoScript{  
       

    $ip = Resolve-DnsName $target
    $VMHostlst = Get-VMHost | Sort-Object Name
    $excel = New-Object -ComObject Excel.Application
    $workbook = $excel.Workbooks.Open($filepath)
    $excel.visible =$true
    $excel.DisplayAlerts =$false
    $excel.WindowState = "xlMaximized"

    $wb = $Workbook.WorkSheets.item("TechSpec-ESXi_Aug") 
    $rangecp = $wb.usedRange
    $rangecp.copy() | Out-Null

    
    $cuser = $env:USERNAME
    $date = Get-Date 


foreach ($vmhost in $VMHostlst ){
    $sheetvar =1
    $sheet = $workbook.Worksheets.Add()

    $sheet.name =$vmhost.Name

    $rngcpy = $sheet.Range("A1")
    $rngcpy.PasteSpecial(-4104)
    $rngcpy.PasteSpecial(8)
    $sheet.Range("A1").select()
    $sheetvar++
}


foreach ($VMHost in $VMHostlst){
$passwordQC = Get-AdvancedSetting -Entity $VMHost -Name Security.PasswordQualityControl | Select @{N="VMHost";E={$VMHost}}, Name, Value 
$actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
$ar = $passwordQC | where {$_.VMHost -eq $VMhost }
    $actwsheet.activate()
    $actwsheet.cells.Item(25,1) = "N"   
    $actwsheet.Cells.Item(25,9) = $ar.Value 
    $actwsheet.Cells.Item(25,10) = $cuser +"  "+ $username 
    $actwsheet.Cells.Item(25,11) = $date
    $actwsheet.Cells.Item(25,12) = $MyInvocation.MyCommand.Name
    if (($passwordQC.Value -ne $null) -and ($passwordQC.Value -match "min=disabled,disabled,disabled,15,15" )) { $actwsheet.Cells.Item(25,13) = "Compliant"
    }else{$actwsheet.Cells.Item(25,13) = "Violation"}


}

foreach ($VMHost in $VMHostlst){
        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $lockout = Get-AdvancedSetting -Entity $VMHost -Name Security.AccountUnlockTime | Select @{N="VMHost";E={$VMHost}}, Name, Value 
        $actwsheet.activate()
        $ar = $lockout | where {$_.VMHost -eq $VMhost }
        $actwsheet.cells.Item(27,1) = "N"   
        $actwsheet.Cells.Item(27,9) = $ar.Value 
        $actwsheet.Cells.Item(27,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(27,11) = $date
        $actwsheet.Cells.Item(27,12) = $MyInvocation.MyCommand.Name
  
if (($lockout.Value -ne $null) -and ($lockout.Value -match "120" ))  { $actwsheet.Cells.Item(27,13) = "Compliant"
}else{$actwsheet.Cells.Item(27,13) = "Violation"}

}

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $aclock = Get-AdvancedSetting -Entity $VMHost -Name Security.AccountLockFailures | Select @{N="VMHost";E={$VMHost}}, Name, Value
        $ar = $aclock | where {$_.VMHost -eq $VMhost }
        $actwsheet.cells.Item(28,1) = "N"   
        $actwsheet.Cells.Item(28,9) = $ar.Value 
        $actwsheet.Cells.Item(28,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(28,11) = $date
        $actwsheet.Cells.Item(28,12) = $MyInvocation.MyCommand.Name
        if (($aclock.Value -ne $null) -and ($aclock.value -eq '10' ))   { $actwsheet.Cells.Item(28,13) = "Compliant"
        }else{$actwsheet.Cells.Item(28,13) = "Violation"}


}

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $logdir = Get-AdvancedSetting -Entity $VMHost -Name Syslog.global.logDir | Select @{N="VMHost";E={$VMHost}},Name, Value
        $scrtchlc = Get-AdvancedSetting -Entity $VMHost -Name ScratchConfig.CurrentScratchLocation | Select @{N="VMHost";E={$VMHost}}, Name, Value
        
        $ar = $logdir | where {$_.VMHost -eq $VMhost }
        $ar1 = $scrtchlc | where {$_.VMHost -eq $VMhost }
        $actwsheet.cells.Item(33,1) = "N"   
        $actwsheet.Cells.Item(33,9) = $ar.Value  +" "+ $ar1.value
        $actwsheet.Cells.Item(33,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(33,11) = $date
        $actwsheet.Cells.Item(33,12) = $MyInvocation.MyCommand.Name

        

        if(($logdir.Value -ne $null) -and ($logdir.Value -ilike "*/scratch/*") -and ($scrtchlc.Value -ilike "/vmfs/volumes/*"))  { 
        $actwsheet.Cells.Item(33,13) = "Compliant"
        

        }else{
        $actwsheet.Cells.Item(33,13) = "Violation"
        


        }
    

    }

foreach ($VMHost in $VMHostlst){
$domstat = Get-VMHostAuthentication -VMHost $VMHost.Name 


$actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
$actwsheet.activate()
$actwsheet.cells.Item(31,1) = "N"   

$actwsheet.Cells.Item(31,10) = $cuser +"  "+ $username 
$actwsheet.Cells.Item(31,11) = $date
$actwsheet.Cells.Item(31,12) = $MyInvocation.MyCommand.Name
$actwsheet.Cells.Item(31,14) = "Process Requirement - Not Health Check or BaseLine"

if($domstat.Domain -eq $NULL)
{
$actwsheet.Cells.Item(31,9) = "Not Joined in Domain" 
}else
{
$actwsheet.Cells.Item(31,9) = $domstat.Domain
}
if ($domstat.Domain -eq $null) { $actwsheet.Cells.Item(31,13) = "N/A"
    }else{$actwsheet.Cells.Item(31,13) = "N/A"}

}

foreach ($VMHost in $VMHostlst){
$domstat = Get-VMHostAuthentication -VMHost $VMHost.Name 


$actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
$actwsheet.activate()
$actwsheet.cells.Item(32,1) = "N"   

$actwsheet.Cells.Item(32,10) = $cuser +"  "+ $username 
$actwsheet.Cells.Item(32,11) = $date
$actwsheet.Cells.Item(32,12) = $MyInvocation.MyCommand.Name
$actwsheet.Cells.Item(32,14) = "Process Requirement - Not Health Check or BaseLine"

if($domstat.Domain -eq $NULL)
{
$actwsheet.Cells.Item(32,9) = "Not Joined in Domain" 
}else
{
$actwsheet.Cells.Item(32,9) = $domstat.Domain
}
if ($domstat.Domain -eq $null) { $actwsheet.Cells.Item(32,13) = "N/A"
    }else{$actwsheet.Cells.Item(32,13) = "N/A"}

}

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $sysloghost = Get-AdvancedSetting -Entity $VMhost -Name Syslog.global.logHost | Select @{N="VMHost";E={$VMHost}}, Name,Value
        $ar = $sysloghost | where {$_.VMHost -eq $VMhost }
        $actwsheet.cells.Item(34,1) = "N"   
        $actwsheet.Cells.Item(34,9) = $ar.Value 
        $actwsheet.Cells.Item(34,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(34,11) = $date
        $actwsheet.Cells.Item(34,12) = $MyInvocation.MyCommand.Name

        if (($sysloghost.Value -ne $null) -and ($sysloghost.value -ilike "udp://*" ) -or ($sysloghost.value -ilike "tcp://*") -or ($sysloghost.value -ilike "ssl://"))  { $actwsheet.Cells.Item(34,13) = "Compliant"
        }else{$actwsheet.Cells.Item(34,13) = "Violation"}
        
 }

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $esxcli = Get-ESXcli -VMHost $VMHost

        $sofacc = $esxcli.software.acceptance.get()
              
        $actwsheet.cells.Item(51,1) = "N"   
        $actwsheet.Cells.Item(51,9) =  $sofacc
        $actwsheet.Cells.Item(51,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(51,11) = $date
        $actwsheet.Cells.Item(51,12) = $MyInvocation.MyCommand.Name       
        
        
        if ($sofacc -match "PartnerSupported")  { $actwsheet.Cells.Item(51,13) = "Compliant" }else{$actwsheet.Cells.Item(51,13) = "Violation"}
    

 }

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $dvfilter = Get-AdvancedSetting -Entity $VMhost -Name Net.DVFilterBindIpAddress | Select @{N="VMHost";E={$VMHost}}, Name,Value
        
        
        $actwsheet.cells.Item(53,1) = "N"   
        $actwsheet.Cells.Item(53,9) =  $dvfilter.Value
        $actwsheet.Cells.Item(53,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(53,11) = $date
        $actwsheet.Cells.Item(53,12) = $MyInvocation.MyCommand.Name       
        
        if ($dvfilter.Value -match "")  { $actwsheet.Cells.Item(53,9) = "Blank" }
        if ($dvfilter.Value -match "")  { $actwsheet.Cells.Item(53,13) = "Compliant" }else{$actwsheet.Cells.Item(53,13) = "Violation"}
    

 }

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $mob = Get-AdvancedSetting -Entity $VMhost -Name Config.HostAgent.plugins.solo.enableMob | Select @{N="VMHost";E={$VMHost}}, Name,Value
        
        
        $actwsheet.cells.Item(52,1) = "N"   
        $actwsheet.Cells.Item(52,9) =  $mob.Value
        $actwsheet.Cells.Item(52,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(52,11) = $date
        $actwsheet.Cells.Item(52,12) = $MyInvocation.MyCommand.Name       
        $actwsheet.Cells.Item(52,14) = "Process Requirement - Not Health Check or BaseLine"

        if ($mob.Value -match "False")  { $actwsheet.Cells.Item(52,13) = "N/A" }else{$actwsheet.Cells.Item(52,13) = "N/A"}
 

 }

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $issue = Get-AdvancedSetting -Entity $VMhost -Name Config.etc.issue | Select @{N="VMHost";E={$VMHost}}, Name,Value
                
        $actwsheet.cells.Item(69,1) = "N"   
        $actwsheet.Cells.Item(69,9) =  $issue.Value
        $actwsheet.Cells.Item(69,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(69,11) = $date
        $actwsheet.Cells.Item(69,12) = $MyInvocation.MyCommand.Name       
        
        if ($issue.Value.Length -le 0)  { 
        $actwsheet.Cells.Item(69,13) = "Violation" 
        $actwsheet.Cells.Item(69,9) =  "No Value Exists" }else{$actwsheet.Cells.Item(69,13) = "Compliant"}
 

 }


foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $motd = Get-AdvancedSetting -Entity $VMhost -Name Config.etc.motd | Select @{N="VMHost";E={$VMHost}}, Name,Value
                
        $actwsheet.cells.Item(70,1) = "N"   
        $actwsheet.Cells.Item(70,9) =  $motd.Value
        $actwsheet.Cells.Item(70,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(70,11) = $date
        $actwsheet.Cells.Item(70,12) = $MyInvocation.MyCommand.Name       
        
        if ($motd.Value.Length -le 0)  { $actwsheet.Cells.Item(70,13) = "Violation" }else{$actwsheet.Cells.Item(70,13) = "Compliant"}
 

 }




foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $inteSShTimeOut = Get-AdvancedSetting -Entity $VMhost -Name UserVars.ESXiShellInteractiveTimeOut  | Select @{N="VMHost";E={$VMHost}}, Name,Value
        
        
        $actwsheet.cells.Item(62,1) = "N"   
        $actwsheet.Cells.Item(62,9) =  $inteSShTimeOut.Value
        $actwsheet.Cells.Item(62,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(62,11) = $date
        $actwsheet.Cells.Item(62,12) = $MyInvocation.MyCommand.Name       
        
        
        if (($inteSShTimeOut.Value -le "600") -or ($inteSShTimeOut.Value -inotmatch "0"))  { $actwsheet.Cells.Item(62,13) = "Compliant" }else{$actwsheet.Cells.Item(62,13) = "Violation"}
    

 }
 
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $SShTimeOut = Get-AdvancedSetting -Entity $VMhost -Name UserVars.ESXiShellTimeOut  | Select @{N="VMHost";E={$VMHost}}, Name,Value
        
        
        $actwsheet.cells.Item(63,1) = "N"   
        $actwsheet.Cells.Item(63,9) =  $SShTimeOut.Value
        $actwsheet.Cells.Item(63,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(63,11) = $date
        $actwsheet.Cells.Item(63,12) = $MyInvocation.MyCommand.Name       
        
        
        if (($SShTimeOut.Value -match "14400") -or ($SShTimeOut.Value -inotmatch "0"))  { $actwsheet.Cells.Item(63,13) = "Compliant" }else{$actwsheet.Cells.Item(63,13) = "Violation"}
    

 }
  
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $ipdhcp = Get-VMHostNetworkAdapter -VMKernel -VMHost $VMHost | Select VMHost,PortGroupName,DeviceName,IP,DhcpEnabled | ?{($_ -match "mgmt") -or ($_ -match "management")}
       
        $actwsheet.cells.Item(54,1) = "N"   
        $actwsheet.Cells.Item(54,9) = $ipdhcp.IP +"   "+"DHCP Enabled=" + $ipdhcp.DhcpEnabled
        $actwsheet.Cells.Item(54,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(54,11) = $date
        $actwsheet.Cells.Item(54,12) = $MyInvocation.MyCommand.Name       
        
        $actwsheet.cells.Item(3,5) = $ipdhcp.VMHost.Name
        $actwsheet.cells.Item(4,5) = $ipdhcp.IP

        if ($ipdhcp -match "DhcpEnabled=False")  { $actwsheet.Cells.Item(54,13) = "Compliant" }else{$actwsheet.Cells.Item(54,13) = "Violation"}
    

 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $snmpst= Get-VMHostService -VMHost $VMHost | where {$_.Key -eq "snmpd"} | Select @{N="VMHost";E={$VMHost}},Key,Running,Required
        
        $actwsheet.cells.Item(56,1) = "N"   
        $actwsheet.Cells.Item(56,9) = "SNMP Service in Running : " +$snmpst.Running
        $actwsheet.Cells.Item(56,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(56,11) = $date
        $actwsheet.Cells.Item(56,12) = $MyInvocation.MyCommand.Name

        if($snmpst.running -match "True")  { 
        $actwsheet.Cells.Item(56,13) = "Violation"
        }else{
        $actwsheet.Cells.Item(56,13) = "Compliant"
        
        }
       
        
             
 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $tsmsshst = Get-VMHostService -VMHost $VMHost | where {$_.Key -eq "TSM-SSH"} | Select @{N="VMHost";E={$VMHost}},Key,Running
        
        $actwsheet.cells.Item(59,1) = "N"   
        $actwsheet.Cells.Item(59,9) =  $tsmsshst.Key+" Service is running : "+$tsmsshst.Running
        $actwsheet.Cells.Item(59,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(59,11) = $date
        $actwsheet.Cells.Item(59,12) = $MyInvocation.MyCommand.Name     
        
        if($tsmsshst.running -match "True")  { $actwsheet.Cells.Item(59,13) = "Violation" }else{$actwsheet.Cells.Item(59,13) = "Compliant"}  
        }

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $lts = Get-VMHostService -VMHost $VMHost | where {$_.Key -eq "TSM"} | Select @{N="VMHost";E={$VMHost}},Key,Running
        
        $actwsheet.cells.Item(60,1) = "N"   
        $actwsheet.Cells.Item(60,9) =  $lts.Key+" Service is running : "+$lts.Running
        $actwsheet.Cells.Item(60,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(60,11) = $date
        $actwsheet.Cells.Item(60,12) = $MyInvocation.MyCommand.Name
        if($lts.running -match "True")  { $actwsheet.Cells.Item(60,13) = "Violation" }else{$actwsheet.Cells.Item(60,13) = "Compliant"}
       
 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $ntpd = Get-VMHostService -VMHost $VMHost | where {$_.Key -eq "ntpd"} | Select @{N="VMHost";E={$VMHost}},Running,Policy
        
        $actwsheet.cells.Item(61,1) = "N"   
        $actwsheet.Cells.Item(61,9) =  " Service is running : "+$ntpd.Running + " Policy Status(Start and Stop with Host) is "+ $ntpd.Policy
        $actwsheet.Cells.Item(61,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(61,11) = $date
        $actwsheet.Cells.Item(61,12) = $MyInvocation.MyCommand.Name 
        
        if(($ntpd.running -match "true") -and ($ntpd.policy -match "on"))   { $actwsheet.Cells.Item(61,13) = "Compliant" }else{$actwsheet.Cells.Item(61,13) = "Violation"}
      
 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $dcui = Get-AdvancedSetting -Entity $VMHost -Name DCUI.Access | Select @{N="VMHost";E={$VMHost}}, Name,Value
        
        $actwsheet.cells.Item(64,1) = "N"   
        $actwsheet.Cells.Item(64,9) =  $dcui.Name + " is given to user "+  $dcui.value
        $actwsheet.Cells.Item(64,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(64,11) = $date
        $actwsheet.Cells.Item(64,12) = $MyInvocation.MyCommand.Name
        if (($dcui.value -ne $null) -and ($dcui.Value -match "root" ))   { $actwsheet.Cells.Item(64,13) = "Compliant" }else{$actwsheet.Cells.Item(64,13) = "Violation"}
      
 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $dcuitot = Get-AdvancedSetting -Entity $VMHost -Name UserVars.DcuiTimeOut | Select @{N="VMHOST";E={$VMHOST}},Name,Value 
        
        $actwsheet.cells.Item(65,1) = "N"   
        $actwsheet.Cells.Item(65,9) =  $dcuitot.Name  + " Value is  "+ $dcuitot.value
        $actwsheet.Cells.Item(65,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(65,11) = $date
        $actwsheet.Cells.Item(65,12) = $MyInvocation.MyCommand.Name
        if ($dcuitot.Value -le "600")  { $actwsheet.Cells.Item(65,13) = "Compliant" }else{$actwsheet.Cells.Item(65,13) = "Violation"}
      
 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $lcmst = $VMHost | Select Name, @{N="Lockdown";E={$_.Extensiondata.Config.adminDisabled}}
        
        $actwsheet.cells.Item(66,1) = "N"   
        $actwsheet.Cells.Item(66,9) =  "Lockdown mode is enabled : "+ $lcmst.Lockdown  
        $actwsheet.Cells.Item(66,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(66,11) = $date
        $actwsheet.Cells.Item(66,12) = $MyInvocation.MyCommand.Name
        if ($lcmst.Lockdown -match "True")  { $actwsheet.Cells.Item(66,13) = "Compliant" }else{$actwsheet.Cells.Item(66,13) = "Violation"}

       
 }

foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $ssl = Get-AdvancedSetting -Entity $VMHost -Name Config.Defaults.security.host.ruissl | Select @{N="VMHost";E={$VMHost}},Name,Value
        
        $actwsheet.cells.Item(77,1) = "N"   
        $actwsheet.Cells.Item(77,9) =  $ssl.Name + " Value is "+ $ssl.Value
        $actwsheet.Cells.Item(77,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(77,11) = $date
        $actwsheet.Cells.Item(77,12) = $MyInvocation.MyCommand.Name
        if (($ssl -ne $null) -and ($ssl -match "True" ))  { $actwsheet.Cells.Item(77,13) = "Compliant" }else{$actwsheet.Cells.Item(77,13) = "Violation"}

       
 }
foreach ($VMHost in $VMHostlst){

        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()

        $actwsheet.cells.Item(40,1) = "N"   
        $actwsheet.Cells.Item(40,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(40,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(40,11) = $date
        $actwsheet.Cells.Item(40,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(41,1) = "N"   
        $actwsheet.Cells.Item(41,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(41,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(41,11) = $date
        $actwsheet.Cells.Item(41,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(42,1) = "N"   
        $actwsheet.Cells.Item(42,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(42,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(42,11) = $date
        $actwsheet.Cells.Item(42,12) = $MyInvocation.MyCommand.Name  


        $actwsheet.cells.Item(47,1) = "N"   
        $actwsheet.Cells.Item(47,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(47,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(47,11) = $date
        $actwsheet.Cells.Item(47,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(48,1) = "N"   
        $actwsheet.Cells.Item(48,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(48,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(48,11) = $date
        $actwsheet.Cells.Item(48,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(49,1) = "N"   
        $actwsheet.Cells.Item(49,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(49,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(49,11) = $date
        $actwsheet.Cells.Item(49,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(43,1) = "N"   
        $actwsheet.Cells.Item(43,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(43,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(43,11) = $date
        $actwsheet.Cells.Item(43,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(44,1) = "N"   
        $actwsheet.Cells.Item(44,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(44,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(44,11) = $date
        $actwsheet.Cells.Item(44,12) = $MyInvocation.MyCommand.Name  

        $actwsheet.cells.Item(45,1) = "N"   
        $actwsheet.Cells.Item(45,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(45,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(45,11) = $date
        $actwsheet.Cells.Item(45,12) = $MyInvocation.MyCommand.Name  


        $actwsheet.cells.Item(46,1) = "N"   
        $actwsheet.Cells.Item(46,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(46,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(46,11) = $date
        $actwsheet.Cells.Item(46,12) = $MyInvocation.MyCommand.Name  
        
        $actwsheet.cells.Item(47,1) = "N"   
        $actwsheet.Cells.Item(47,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(47,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(47,11) = $date
        $actwsheet.Cells.Item(47,12) = $MyInvocation.MyCommand.Name  
        
        $actwsheet.cells.Item(48,1) = "N"    
        $actwsheet.Cells.Item(48,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(48,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(48,11) = $date
        $actwsheet.Cells.Item(48,12) = $MyInvocation.MyCommand.Name 
        
        $actwsheet.cells.Item(49,1) = "N"    
        $actwsheet.Cells.Item(49,9) =  "Refer the WorkSheet with Name of " +$ip.NameHost +" or " + $target+ " for Details"
        $actwsheet.Cells.Item(49,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(49,11) = $date
        $actwsheet.Cells.Item(49,12) = $MyInvocation.MyCommand.Name 
        
        $actwsheet.Cells.Item(47,13) = "Compliant"
        $actwsheet.Cells.Item(48,13) = "Compliant"
        $actwsheet.Cells.Item(49,13) = "Compliant"
        $actwsheet.Cells.Item(43,13) = "Compliant"
        $actwsheet.Cells.Item(44,13) = "Compliant"
        $actwsheet.Cells.Item(45,13) = "Compliant"
        $actwsheet.Cells.Item(46,13) = "Compliant"
        $actwsheet.Cells.Item(47,13) = "Compliant"
        $actwsheet.Cells.Item(48,13) = "Compliant"
        $actwsheet.Cells.Item(49,13) = "Compliant"
        $actwsheet.Cells.Item(40,13) = "Compliant"
        $actwsheet.Cells.Item(41,13) = "Compliant"
        $actwsheet.Cells.Item(42,13) = "Compliant"         
             
 }
foreach ($VMHost in $VMHostlst){
        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        $ports1 = Get-VMHostFirewallException -VMHost $VMHost | Where {$_.Enabled -eq "True"}
        
        $actwsheet.cells.Item(55,1) = "N" 
        for($i=0;$i -le $ports1.Count; $i++){
                $cell = $actwsheet.Range('I55:I55')
                $cell.Value2 += $ports1[$i].Name +" "+$ports1[$i].Enabled + " "+$ports1[$i].IncomingPorts +""+$ports1[$i].OutgoingPorts+ " "+ $ports1[$i].Protocols +"`r`n"
        }
        
        $actwsheet.Cells.Item(55,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(55,11) = $date
        $actwsheet.Cells.Item(55,12) = $MyInvocation.MyCommand.Name 
        $actwsheet.Cells.Item(55,13) = "Compliant"  


              
 }
foreach ($VMHost in $VMHostlst){
        $actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
        $actwsheet.activate()
        
        $tlsver = Get-AdvancedSetting -Entity $VMHost -Name UserVars.EsxiVPsDisabledProtocols | Select @{N="VMHost";E={$VMHost}},Name,Value


        $actwsheet.cells.Item(78,1) = "N"   
        $actwsheet.Cells.Item(78,9) =  $tlsver.value
        $actwsheet.Cells.Item(78,10) = $cuser +"  "+ $username 
        $actwsheet.Cells.Item(78,11) = $date
        $actwsheet.Cells.Item(78,12) = $MyInvocation.MyCommand.Name


        if (($tlsver.Value -match "tlsv1.1") -and ($tlsver.Value -match "tlsv1"))  { $actwsheet.Cells.Item(78,13) = "Violation" }else{$actwsheet.Cells.Item(77,13) = "Compliant"}



        


              
 }



 foreach($VMHost in $VMHostlst){
$actwsheet = $workbook.worksheets | where {$_.name -eq $VMHost }
$actwsheet.activate()

$lastRow = $actwsheet.UsedRange.Rows.Count

for ($i = 3; $i -le $lastRow; $i++){
if (($actwSheet.Range("m$i").Text) -match "Compliant")
{
$actwsheet.Range("m$i").Interior.ColorIndex = 4
}

if (($actwsheet.Range("m$i").Text) -match "Violation")
{
$actwsheet.Range("m$i").Interior.ColorIndex = 3
}
}


}



### vDSwitch & vDPortGroup########
$sheet = $workbook.Worksheets.Add()
$ip = Resolve-DnsName $target

$tarlen = $target |measure -Character

if($tarlen.Characters -ge 31){$sheet.name = $ip.NameHost}else { $sheet.name=$target}
    $actwsheet = $workbook.worksheets | where {$_.name -eq $target -or $_.name -eq $ip.NameHost }
    $actwsheet.activate()   
    $range = $actwsheet.Range("b2:q2")
    $range.Font.Size=12
    $range.Font.Name ="Calibri"
    $range.Font.Bold = $true
    $range.VerticalAlignment = -4108
    $range.HorizontalAlignment = -4108

    $actwsheet.Cells.Item(2,2) = "Section"
    $actwsheet.Cells.Item(2,3) = "Description"
    $actwsheet.Cells.Item(2,4) = "Recommended Value"
    $actwsheet.Cells.Item(2,5) = "VDSwitch / VDPortGroup Name"
    $actwsheet.Cells.Item(2,6) = "AllowPromiscuous "
    $actwsheet.Cells.Item(2,7) = "MacChanges "
    $actwsheet.Cells.Item(2,8) = "ForgedTransmits "
    
    $actwsheet.Cells.Item(3,2) = "GN.1.4.3.1"
    $actwsheet.Cells.Item(3,3) = "Forged Transmits"
    $actwsheet.Cells.Item(3,4) = " Reject Forged Transmits on all virtual switches and port groups "
    $actwsheet.Cells.Item(4,2) = "GN.1.4.4.1"
    $actwsheet.Cells.Item(4,3) = "Promiscuous Mode disabled"
    $actwsheet.Cells.Item(4,4) = " Reject Promiscuous mode on all virtual switches and port groups "
    $actwsheet.Cells.Item(5,2) = "GN.1.4.5.1"
    $actwsheet.Cells.Item(5,3) = "MAC address changes"
    $actwsheet.Cells.Item(5,4) = " Reject MAC Address Changes on all virtual switches and port groups "

    $counter = 6

    $vdswitchprn = Get-VDSwitch | Get-VDSecurityPolicy | Sort Name

    $i=0 
    $vdswitchprn | ForEach-Object {
    
    $actwsheet.Cells.Item($counter,5) = $vdswitchprn[$i].VDSwitch.Name
    $actwsheet.Cells.Item($counter,6) = $_.AllowPromiscuous
    $actwsheet.Cells.Item($counter,7) = $_.MacChanges
    $actwsheet.Cells.Item($counter,8) = $_.ForgedTransmits

    $counter++
    $i++

   
    }
   

    $vdpgroupprn = Get-VDPortgroup | ?{$_.IsUplink -eq $false} | Get-VDSecurityPolicy | Sort Name
    $z=0
    $vdpgroupprn | ForEach-Object {
    
    $actwsheet.Cells.Item($counter,5) = $vdpgroupprn[$z].VDPortgroup.Name
    $actwsheet.Cells.Item($counter,6) = $_.AllowPromiscuous
    $actwsheet.Cells.Item($counter,7) = $_.MacChanges
    $actwsheet.Cells.Item($counter,8) = $_.ForgedTransmits

    $counter++
    $z++

   
    }




    $vdswitch = Get-VDSwitch | Get-VDSecurityPolicy | Select AllowPromiscuous,ForgedTransmits,MacChanges | Select-String "True"
    $vdpgroup = Get-VDPortgroup | ?{$_.IsUplink -eq $false} | Get-VDSecurityPolicy | Select-String "True"

    $actwsheet.Cells.Item(15,3) = "Status "
    $actwsheet.Cells.Item(15,3).Font.Bold =$true
    $actwsheet.Cells.Item(15,3).HorizontalAlignment = -4108

    if(($vdpgroup -eq $null) -and ($vdswitch -eq $null)){
    $actwsheet.Cells.Item(15,4) = "Compliant " 
    }else {$actwsheet.Cells.Item(15,4) = "Violation" }
    $excel.ActiveSheet.UsedRange.EntireColumn.AutoFit()
  


  ### vDPortGroup - OverRide ########
$sheet = $workbook.Worksheets.Add()
$ip = Resolve-DnsName $target

$tarlen = $target |measure -Character

if($tarlen.Characters -ge 31){$sheet.name = "PortGroup_Override" }else { $sheet.name="PGOverride"}
    $actwsheet = $workbook.worksheets | where {$_.name -eq "PortGroup_Override" -or $_.name -eq "PGOverride" }
    $actwsheet.activate()   
    $range = $actwsheet.Range("b2:q2")
    $range.Font.Size=12
    $range.Font.Name ="Calibri"
    $range.Font.Bold = $true
    $range.VerticalAlignment = -4108
    $range.HorizontalAlignment = -4108

    $actwsheet.Cells.Item(2,2) = "Section"
    $actwsheet.Cells.Item(2,3) = "Description"
    $actwsheet.Cells.Item(2,4) = "Recommended Value"
    $actwsheet.Cells.Item(2,5) = "VDSwitch / VDPortGroup Name"
    $actwsheet.Cells.Item(2,6) = "VlanOverrideAllowed "
    $actwsheet.Cells.Item(2,7) = "UplinkTeamingOverrideAllowed  "
    $actwsheet.Cells.Item(2,8) = "SecurityPolicyOverrideAllowed "
    $actwsheet.Cells.Item(2,9) = "IpfixOverrideAllowed "
    $actwsheet.Cells.Item(2,10) = "BlockOverrideAllowed  "
    $actwsheet.Cells.Item(2,11) = "ShapingOverrideAllowed "
    $actwsheet.Cells.Item(2,12) = "VendorConfigOverrideAllowed "
    $actwsheet.Cells.Item(2,13) = "TrafficFilterOverrideAllowed "
    $actwsheet.Cells.Item(2,14) = "PortConfigResetAtDisconnect "

    $actwsheet.Cells.Item(3,2) = "GN.1.4.5.4"
    $actwsheet.Cells.Item(3,3) = "Overriding Networking Policies on Distributed Port Level"
    $actwsheet.Cells.Item(3,4) = " Port-level configuration overrides are disabled by default "
    
    $counter = 6

    $vdpgroupovrde = Get-VDPortgroup | Get-View | Select Name,@{N="VlanOverrideAllowed";E={$_.Config.Policy.VlanOverrideAllowed}},
                        @{N="UplinkTeamingOverrideAllowed";E={$_.Config.Policy.UplinkTeamingOverrideAllowed}},
                        @{N="SecurityPolicyOverrideAllowed";E={$_.Config.Policy.SecurityPolicyOverrideAllowed}},
                        @{N="IpfixOverrideAllowed";E={$_.Config.Policy.IpfixOverrideAllowed}},
                        @{N="BlockOverrideAllowed";E={$_.Config.Policy.BlockOverrideAllowed}},
                        @{N="ShapingOverrideAllowed";E={$_.Config.Policy.ShapingOverrideAllowed}},
                        @{N="VendorConfigOverrideAllowed";E={$_.Config.Policy.VendorConfigOverrideAllowed}},
                        @{N="TrafficFilterOverrideAllowed";E={$_.Config.Policy.TrafficFilterOverrideAllowed}},
                        @{N="PortConfigResetAtDisconnect";E={$_.Config.Policy.PortConfigResetAtDisconnect}} | Sort Name
    $u=0
    $vdpgroupovrde | ForEach-Object {
    
    $actwsheet.Cells.Item($counter,5) = $vdpgroupovrde[$u].Name
    $actwsheet.Cells.Item($counter,6) = $_.VlanOverrideAllowed
    $actwsheet.Cells.Item($counter,7) = $_.UplinkTeamingOverrideAllowed
    $actwsheet.Cells.Item($counter,8) = $_.SecurityPolicyOverrideAllowed
    $actwsheet.Cells.Item($counter,9) = $_.IpfixOverrideAllowed
    $actwsheet.Cells.Item($counter,10) = $_.BlockOverrideAllowed
    $actwsheet.Cells.Item($counter,11) = $_.ShapingOverrideAllowed
    $actwsheet.Cells.Item($counter,12) = $_.VendorConfigOverrideAllowed
    $actwsheet.Cells.Item($counter,13) = $_.TrafficFilterOverrideAllowed
    $actwsheet.Cells.Item($counter,14) = $_.PortConfigResetAtDisconnect
   
    $counter++
    
    $u++

   
    }

  

}

#$workbook.SaveAs($filepath)
#$Excel.Workbooks.Close()
#$Excel.Quit() 


#"C:\Users\SureshKannanR\Documents\VMWare_ESXi_Checklist.xlsx"



if($target -eq [string]::empty) {
    write-host "Target server FQDN or IP cannot be empty, please try again." -foregroundcolor "red" }
else
{

    $CurrentVIMode = Get-PowerCLIConfiguration
    Set-PowerCLIConfiguration -DefaultVIServerMode Single -confirm:$false > $NULL 2>&1

    Connect-VIServer $target
    
    MHC_AutoScript

    

    Disconnect-VIServer -Confirm -Force

}