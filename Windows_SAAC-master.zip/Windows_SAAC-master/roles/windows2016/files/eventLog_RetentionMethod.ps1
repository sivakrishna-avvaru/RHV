Param($logName, $retentionDays, $overFlowAction)

$logName = $logName
$retentionDays = $retentionDays
$overFlowAction = $overFlowAction

Limit-Eventlog -Logname $logName -OverflowAction $overFlowAction -RetentionDays $retentionDays
