export VMWARE_PASSWORD='passw0rd-P'
export VMWARE_USER='Administrator@vSphere.localcloud'
export VMWARE_HOST='10.177.181.15'
ansible-playbook ./site.yaml  --ssh-extra-args=' -o StrictHostKeyChecking=no  -o UserKnownHostsFile=/dev/null '  -vvv
